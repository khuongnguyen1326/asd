/****************************************************************************
 * Product Name : HI7700/4
 *   Copyright (c) 2000(2005) Renesas Technology Corp.
 *   and Renesas Solutions Corp. All rights reserved.
 * File Name : kernel_cfg.c
 * File Version : 20050512
 ****************************************************************************/
#include "itron.h"
#include "kernel.h"
#include "kernel_id.h"
#include "kernel_id_sys.h"
#include "kernel_sys.h"
#include "kernel_macro.h"
#include "kernel_sys_inireg.h"
#include "kernel_def_main.h"
#include "kernel_def_default.h"
#include "kernel_def_sys.h"

#include "kernel_cfg_tbl.h"
#include "kernel_cfg_main.h"
#include "kernel_cfg_default.h"
#include "kernel_cfg_inidata.def"
#include "kernel_cfg_inc.def"
