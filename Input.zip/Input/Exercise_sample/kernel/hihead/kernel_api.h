/****************************************************************************
 * Product Name : HI7700/4
 *   Copyright (c) 2000(2005) Renesas Technology Corp.
 *   and Renesas Solutions Corp. All rights reserved.
 * File Name : kernel_api.h
 * File Version : 20050512
 ****************************************************************************/
#ifndef _HIOS_KERNEL_API_H
#define _HIOS_KERNEL_API_H

/****************************************************************************/
/*	  Service call type definition											*/
/****************************************************************************/
#pragma pack 4

/*** Task management						***********/
typedef	ER	(*API_CRE_TSK)(ID, T_CTSK *);
typedef	ER_ID	(*API_ACRE_TSK)(T_CTSK *);
typedef	ER	(*API_VSCR_TSK)(ID, T_CTSK *);
typedef	ER	(*API_DEL_TSK)(ID);
typedef	ER	(*API_ACT_TSK)(ID);
typedef	ER_UINT	(*API_CAN_ACT)(ID);
typedef	ER	(*API_STA_TSK)(ID, VP_INT);
typedef	void	(*API_EXT_TSK)(void);
typedef	void	(*API_EXD_TSK)(void);
typedef	ER	(*API_TER_TSK)(ID);
typedef	ER	(*API_CHG_PRI)(ID, PRI);
typedef	ER	(*API_GET_PRI)(ID, PRI *);
typedef	ER	(*API_REF_TSK)(ID, T_RTSK *);
typedef	ER	(*API_REF_TST)(ID, T_RTST *);
typedef	ER	(*API_VCHG_TMD)(UINT);

/*** Task-dependent synchronization			***********/
typedef	ER	(*API_SLP_TSK)(void);
typedef	ER	(*API_TSLP_TSK)(TMO);
typedef	ER	(*API_WUP_TSK)(ID);
typedef	ER_UINT	(*API_CAN_WUP)(ID);
typedef	ER	(*API_REL_WAI)(ID);
typedef	ER	(*API_SUS_TSK)(ID);
typedef	ER	(*API_RSM_TSK)(ID);
typedef	ER	(*API_FRSM_TSK)(ID);
typedef	ER	(*API_DLY_TSK)(RELTIM);
typedef	ER	(*API_VSET_TFL)(ID, UINT);
typedef	ER	(*API_VCLR_TFL)(ID, UINT);
typedef	ER	(*API_VWAI_TFL)(UINT, UINT *);
typedef	ER	(*API_VPOL_TFL)(UINT, UINT *);
typedef	ER	(*API_VTWAI_TFL)(UINT, UINT *, TMO);

/*** Task exception process					***********/
typedef	ER	(*API_DEF_TEX)(ID, T_DTEX *);
typedef	ER	(*API_RAS_TEX)(ID, TEXPTN);
typedef	ER	(*API_DIS_TEX)(void);
typedef	ER	(*API_ENA_TEX)(void);
typedef	BOOL	(*API_SNS_TEX)(void);
typedef	ER	(*API_REF_TEX)(ID, T_RTEX *);

/*** Synchronization and communication		***********/
	/*** Semaphore			  *************/
typedef	ER	(*API_CRE_SEM)(ID, T_CSEM *);
typedef	ER_ID	(*API_ACRE_SEM)(T_CSEM *);
typedef	ER	(*API_DEL_SEM)(ID);
typedef	ER	(*API_SIG_SEM)(ID);
typedef	ER	(*API_WAI_SEM)(ID);
typedef	ER	(*API_POL_SEM)(ID);
typedef	ER	(*API_TWAI_SEM)(ID, TMO);
typedef	ER	(*API_REF_SEM)(ID, T_RSEM *);

	/*** Eventflag			  *************/
typedef	ER	(*API_CRE_FLG)(ID, T_CFLG *);
typedef	ER_ID	(*API_ACRE_FLG)(T_CFLG *);
typedef	ER	(*API_DEL_FLG)(ID);
typedef	ER	(*API_SET_FLG)(ID, FLGPTN);
typedef	ER	(*API_CLR_FLG)(ID, FLGPTN);
typedef	ER	(*API_WAI_FLG)(ID, FLGPTN, MODE, FLGPTN *);
typedef	ER	(*API_POL_FLG)(ID, FLGPTN, MODE, FLGPTN *);
typedef	ER	(*API_TWAI_FLG)(ID, FLGPTN, MODE, FLGPTN *, TMO);
typedef	ER	(*API_REF_FLG)(ID, T_RFLG *);

	/*** Data queue			  *************/
typedef	ER	(*API_CRE_DTQ)(ID, T_CDTQ *);
typedef	ER_ID	(*API_ACRE_DTQ)(T_CDTQ *);
typedef	ER	(*API_DEL_DTQ)(ID);
typedef	ER	(*API_SND_DTQ)(ID, VP_INT);
typedef	ER	(*API_PSND_DTQ)(ID, VP_INT);
typedef	ER	(*API_TSND_DTQ)(ID, VP_INT, TMO);
typedef	ER	(*API_FSND_DTQ)(ID, VP_INT);
typedef	ER	(*API_RCV_DTQ)(ID, VP_INT *);
typedef	ER	(*API_PRCV_DTQ)(ID, VP_INT *);
typedef	ER	(*API_TRCV_DTQ)(ID, VP_INT *, TMO);
typedef	ER	(*API_REF_DTQ)(ID, T_RDTQ *);

	/*** Mailbox			  *************/
typedef	ER	(*API_CRE_MBX)(ID, T_CMBX *);
typedef	ER_ID	(*API_ACRE_MBX)(T_CMBX *);
typedef	ER	(*API_DEL_MBX)(ID);
typedef	ER	(*API_SND_MBX)(ID, T_MSG *);
typedef	ER	(*API_RCV_MBX)(ID, T_MSG **);
typedef	ER	(*API_PRCV_MBX)(ID, T_MSG **);
typedef	ER	(*API_TRCV_MBX)(ID, T_MSG **, TMO);
typedef	ER	(*API_REF_MBX)(ID, T_RMBX *);

	/*** Mutex				  *************/
typedef	ER	(*API_CRE_MTX)(ID, T_CMTX *);
typedef	ER_ID	(*API_ACRE_MTX)(T_CMTX *);
typedef	ER	(*API_DEL_MTX)(ID);
typedef	ER	(*API_LOC_MTX)(ID);
typedef	ER	(*API_PLOC_MTX)(ID);
typedef	ER	(*API_TLOC_MTX)(ID, TMO);
typedef	ER	(*API_UNL_MTX)(ID);
typedef	ER	(*API_REF_MTX)(ID, T_RMTX *);

	/*** Message buffer		  *************/
typedef	ER	(*API_CRE_MBF)(ID, T_CMBF *);
typedef	ER_ID	(*API_ACRE_MBF)(T_CMBF *);
typedef	ER	(*API_DEL_MBF)(ID);
typedef	ER	(*API_SND_MBF)(ID, VP, UINT);
typedef	ER	(*API_PSND_MBF)(ID, VP, UINT);
typedef	ER	(*API_TSND_MBF)(ID, VP, UINT, TMO);
typedef	ER_UINT	(*API_RCV_MBF)(ID, VP);
typedef	ER_UINT	(*API_PRCV_MBF)(ID, VP);
typedef	ER_UINT	(*API_TRCV_MBF)(ID, VP, TMO);
typedef	ER	(*API_REF_MBF)(ID, T_RMBF *);

/*** Memorypool management					***********/
	/*** Fixed-size			  *************/
typedef	ER	(*API_CRE_MPF)(ID, T_CMPF *);
typedef	ER_ID	(*API_ACRE_MPF)(T_CMPF *);
typedef	ER	(*API_DEL_MPF)(ID);
typedef	ER	(*API_GET_MPF)(ID, VP *);
typedef	ER	(*API_PGET_MPF)(ID, VP *);
typedef	ER	(*API_TGET_MPF)(ID, VP *, TMO);
typedef	ER	(*API_REL_MPF)(ID, VP);
typedef	ER	(*API_REF_MPF)(ID, T_RMPF *);

	/*** Variable-size		  *************/
typedef	ER	(*API_CRE_MPL)(ID, T_CMPL *);
typedef	ER_ID	(*API_ACRE_MPL)(T_CMPL *);
typedef	ER	(*API_DEL_MPL)(ID);
typedef	ER	(*API_GET_MPL)(ID, UINT, VP *);
typedef	ER	(*API_PGET_MPL)(ID, UINT, VP *);
typedef	ER	(*API_TGET_MPL)(ID, UINT, VP *, TMO);
typedef	ER	(*API_REL_MPL)(ID, VP);
typedef	ER	(*API_REF_MPL)(ID, T_RMPL *);

/*** Timer management						***********/
	/*** System time management ***********/
typedef	ER	(*API_SET_TIM)(SYSTIM *);
typedef	ER	(*API_GET_TIM)(SYSTIM *);

	/*** Cyclic handler		  *************/
typedef	ER	(*API_CRE_CYC)(ID, T_CCYC *);
typedef	ER_ID	(*API_ACRE_CYC)(T_CCYC *);
typedef	ER	(*API_DEL_CYC)(ID);
typedef	ER	(*API_STA_CYC)(ID);
typedef	ER	(*API_STP_CYC)(ID);
typedef	ER	(*API_REF_CYC)(ID, T_RCYC *);

	/*** Alarm handler		  *************/
typedef	ER	(*API_CRE_ALM)(ID, T_CALM *);
typedef	ER_ID	(*API_ACRE_ALM)(T_CALM *);
typedef	ER	(*API_DEL_ALM)(ID);
typedef	ER	(*API_STA_ALM)(ID, RELTIM);
typedef	ER	(*API_STP_ALM)(ID);
typedef	ER	(*API_REF_ALM)(ID, T_RALM *);

	/*** Overrun handler	  *************/
typedef	ER	(*API_DEF_OVR)(T_DOVR *);
typedef	ER	(*API_STA_OVR)(ID, OVRTIM);
typedef	ER	(*API_STP_OVR)(ID);
typedef	ER	(*API_REF_OVR)(ID, T_ROVR *);

/*** System status management				***********/
typedef	ER	(*API_ROT_RDQ)(PRI);
typedef	ER	(*API_GET_TID)(ID *);
typedef	ER	(*API_LOC_CPU)(void);
typedef	ER	(*API_UNL_CPU)(void);
typedef	ER	(*API_DIS_DSP)(void);
typedef	ER	(*API_ENA_DSP)(void);
typedef	BOOL	(*API_SNS_CTX)(void);
typedef	BOOL	(*API_SNS_LOC)(void);
typedef	BOOL	(*API_SNS_DSP)(void);
typedef	BOOL	(*API_SNS_DPN)(void);
typedef	void	(*API_VSYS_DWN)(W, ER, VW, VW);
typedef	ER	(*API_VGET_TRC)(VW, VW, VW, VW);
typedef	ER	(*API_IVBGN_INT)(UINT);
typedef	ER	(*API_IVEND_INT)(UINT);

/*** Interrupt management					***********/
typedef	ER	(*API_DEF_INH)(INHNO, T_DINH *);
typedef	ER	(*API_CHG_IMS)(IMASK);
typedef	ER	(*API_GET_IMS)(IMASK *);

/*** Service call management				***********/
typedef	ER	(*API_DEF_SVC)(FN, T_DSVC *);
typedef	ER_UINT	(*API_CAL_SVC)(FN, ...);

/*** System construction management			***********/
typedef	ER	(*API_DEF_EXC)(EXCNO, T_DEXC *);
typedef	ER	(*API_VDEF_TRP)(UINT, T_DTRP *);
typedef	ER	(*API_REF_CFG)(T_RCFG *);
typedef	ER	(*API_REF_VER)(T_RVER *);

/*** Cache management						***********/
#ifdef _SH4ALDSP
typedef ER  (*API_VCLR_CAC)(VP, VP, MODE);
#else
typedef	ER	(*API_VCLR_CAC)(VP, VP);
#endif

typedef	ER	(*API_VFLS_CAC)(VP, VP);

#ifdef _SH4ALDSP
typedef ER  (*API_VINV_CAC)(VP, VP, MODE);
#else
typedef	ER	(*API_VINV_CAC)(void);
#endif

#ifdef _SH4ALDSP
typedef ER  (*API_VINI_CAC)(ATR);
#else
typedef	void	(*API_VINI_CAC)(UW, UW, UW);
#endif

/*** Debugger support SVC ***/
typedef	ER	(*API_DACT_TRC)(UW, VW *, UW);
typedef	ER	(*API_DDEL_TSK)(ID);
typedef	ER	(*API_DSUS_TSK)(ID, BOOL);
typedef	ER	(*API_DTER_TSK)(ID, BOOL);

/*** DSP standby management					***********/
typedef	ER_UINT	(*API_VCHG_COP)(ATR);

/****************************************************************************/
/* CNFGTBL structure (include SVC jump table)								*/
/****************************************************************************/
typedef struct {
	/**	   CNFGTBL											*******/
	UH	cf_vctmode;	/* VECTOR mode (ROM/RAM)	*/
	UH	cf_trpmode;	/* TRAPA  mode (ROM/RAM)	*/
	UH	cf_maxexccd;	/* hi_maxexccd	*/
	UH	cf_maxtrpno;	/* hi_maxtrpno	*/
	UH	cf_trcfunc;	/* hi_debug (trace function for DX)	*/
	UH	cf_anavec;	/* Reserved	*/
	FP	cf_vctcpyp;	/* Vector copy routine	*/
	FP	cf_trpcpyp;	/* TRAPA  copy routine	*/
	FP	cf_dispadr;	/* Dispatcher address	*/
	FP	cf_svtrcp;	/* Trace routine	*/
	B 	*cf_knlnamep;	/* string address of kernel name 	*/
	FP	cf_tmslcp;	/* Time slice processing routine	*/
	FP	cf_tmqinsp;	/* Timer queuing routine	*/
	FP	cf_tmqdltp;	/* Timer de-queuing routine	*/
	FP	cf_qucycp;	/* CYC queuing routine	*/
	FP	cf_dqcycp;	/* CYC de-queuing routine	*/
	FP	cf_qualmp;	/* ALM queuing routine	*/
	FP	cf_dqalmp;	/* ALM de-queuing routine	*/
	FP	cf_priqinsp;	/* Pri-based queue insert routine	*/
	FP	cf_stkallcp;	/* Shared stack allocation routine	*/
	FP	cf_mplallcp;	/* Var.mem.blk allocation routine	*/
	FP	cf_smbfsndp;	/* SMBF queue service routine	*/
	FP	cf_setnamep;	/* Name set routine	*/
	FP	cf_getnamep;	/* Name get routine	*/
	FP	cf_getjnamep;	/* Name get routine of JSR-SVC	*/
	FP	cf_clrnamep;	/* Name clear routine	*/
	FP	cf_srhnamep;	/* Name search routine	*/
	FP	cf_hdini;	/* Initialize DX daemon area	*/
	FP	cf_tlbexc;	/* Reserved	*/
	VP	cf_inipblkp;	/* virtual pagepool CB initial address	*/
	VP	cf_iniptblp;	/* physical pagepool CB initial address	*/
	VP	cf_inipgixp;	/* pagetable index and initial address	*/
	VP	cf_pplallcp;	/* pagepool allocate routine address	*/
	VP	cf_prefinfp;	/* build side PREF information table	*/
	FP	*cf_teccrep;	/* Task Extend Context create routine	*/
	FP	*cf_tecrstp;	/* Task Extend Context restore routine	*/
	FP	*cf_tecsavp;	/* Task Extend Context save routine	*/
	FP	*cf_tecdltp;	/* Task Extend Context delete routine	*/
	FP	*cf_tecextp;	/* Exit routine for Extended Context	*/
	FP	*cf_tecexdp;	/* task extend context address	*/
	FP	cf_ent_svc110;	/* entry address for chg_ims	*/
	FP	cf_ent_svc210;	/* entry address for chg_ims	*/
	FP	cf_dispadr_sw;	/* Dispatcher_sw address	*/
	FP	cf_texsetp;     /* task exception process(for task)			*/
	FP	cf_texsetip;    /* task exception process(for non-task)		*/
	FP	cf_cretsk;      /* cre_tsk address(for static-API process)	*/
	FP	cf_vscrtsk;     /* vscr_tsk									*/
	FP	cf_deftex;      /* def_tex									*/
	FP	cf_cresem;      /* cre_sem									*/
	FP	cf_creflg;      /* cre_flg									*/
	FP	cf_credtq;      /* cre_dtq									*/
	FP	cf_crembx;      /* cre_mbx									*/
	FP	cf_cremtx;      /* cre_mtx									*/
	FP	cf_crembf;      /* cre_mbf									*/
	FP	cf_crempf;      /* cre_mpf									*/
	FP	cf_crempl;      /* cre_mpl									*/
	FP	cf_crecyc;      /* cre_cyc									*/
	FP	cf_crealm;      /* cre_alm									*/
	FP	cf_defovr;      /* def_ovr									*/
	FP	cf_defsvc;      /* def_svc									*/
	FP	cf_definh;      /* def_inh									*/
	FP	cf_defexc;      /* def_exc									*/
	FP	cf_vdeftrp;     /* vdef_trp									*/

	/**	   INTFCTBL											*******/

/*** Task management						***********/
	API_CRE_TSK	intfc_cre_tsk;
	API_ACRE_TSK	intfc_acre_tsk;
	API_VSCR_TSK	intfc_vscr_tsk;
	API_DEL_TSK	intfc_del_tsk;
	API_ACT_TSK	intfc_act_tsk;
	API_CAN_ACT	intfc_can_act;
	API_STA_TSK	intfc_sta_tsk;
	API_EXT_TSK	intfc_ext_tsk;
	API_EXD_TSK	intfc_exd_tsk;
	API_TER_TSK	intfc_ter_tsk;
	API_CHG_PRI	intfc_chg_pri;
	API_GET_PRI	intfc_get_pri;
	API_REF_TSK	intfc_ref_tsk;
	API_REF_TST	intfc_ref_tst;
	API_VCHG_TMD	intfc_vchg_tmd;

/*** Task-dependent synchronization			***********/
	API_SLP_TSK	intfc_slp_tsk;
	API_TSLP_TSK	intfc_tslp_tsk;
	API_WUP_TSK	intfc_wup_tsk;
	API_CAN_WUP	intfc_can_wup;
	API_REL_WAI	intfc_rel_wai;
	API_SUS_TSK	intfc_sus_tsk;
	API_RSM_TSK	intfc_rsm_tsk;
	API_FRSM_TSK	intfc_frsm_tsk;
	API_DLY_TSK	intfc_dly_tsk;
	API_VSET_TFL	intfc_vset_tfl;
	API_VCLR_TFL	intfc_vclr_tfl;
	API_VWAI_TFL	intfc_vwai_tfl;
	API_VPOL_TFL	intfc_vpol_tfl;
	API_VTWAI_TFL	intfc_vtwai_tfl;

/*** Task exception process					***********/
	API_DEF_TEX	intfc_def_tex;
	API_RAS_TEX	intfc_ras_tex;
	API_DIS_TEX	intfc_dis_tex;
	API_ENA_TEX	intfc_ena_tex;
	API_SNS_TEX	intfc_sns_tex;
	API_REF_TEX	intfc_ref_tex;

/*** Synchronization and communication		***********/
	/*** Semaphore			  *************/
	API_CRE_SEM	intfc_cre_sem;
	API_ACRE_SEM	intfc_acre_sem;
	API_DEL_SEM	intfc_del_sem;
	API_SIG_SEM	intfc_sig_sem;
	API_WAI_SEM	intfc_wai_sem;
	API_POL_SEM	intfc_pol_sem;
	API_TWAI_SEM	intfc_twai_sem;
	API_REF_SEM	intfc_ref_sem;

	/*** Eventflag			  *************/
	API_CRE_FLG	intfc_cre_flg;
	API_ACRE_FLG	intfc_acre_flg;
	API_DEL_FLG	intfc_del_flg;
	API_SET_FLG	intfc_set_flg;
	API_CLR_FLG	intfc_clr_flg;
	API_WAI_FLG	intfc_wai_flg;
	API_POL_FLG	intfc_pol_flg;
	API_TWAI_FLG	intfc_twai_flg;
	API_REF_FLG	intfc_ref_flg;

	/*** Data queue			  *************/
	API_CRE_DTQ	intfc_cre_dtq;
	API_ACRE_DTQ	intfc_acre_dtq;
	API_DEL_DTQ	intfc_del_dtq;
	API_SND_DTQ	intfc_snd_dtq;
	API_PSND_DTQ	intfc_psnd_dtq;
	API_TSND_DTQ	intfc_tsnd_dtq;
	API_FSND_DTQ	intfc_fsnd_dtq;
	API_RCV_DTQ	intfc_rcv_dtq;
	API_PRCV_DTQ	intfc_prcv_dtq;
	API_TRCV_DTQ	intfc_trcv_dtq;
	API_REF_DTQ	intfc_ref_dtq;

	/*** Mailbox			  *************/
	API_CRE_MBX	intfc_cre_mbx;
	API_ACRE_MBX	intfc_acre_mbx;
	API_DEL_MBX	intfc_del_mbx;
	API_SND_MBX	intfc_snd_mbx;
	API_RCV_MBX	intfc_rcv_mbx;
	API_PRCV_MBX	intfc_prcv_mbx;
	API_TRCV_MBX	intfc_trcv_mbx;
	API_REF_MBX	intfc_ref_mbx;

	/*** Mutex				  *************/
	API_CRE_MTX	intfc_cre_mtx;
	API_ACRE_MTX	intfc_acre_mtx;
	API_DEL_MTX	intfc_del_mtx;
	API_LOC_MTX	intfc_loc_mtx;
	API_PLOC_MTX	intfc_ploc_mtx;
	API_TLOC_MTX	intfc_tloc_mtx;
	API_UNL_MTX	intfc_unl_mtx;
	API_REF_MTX	intfc_ref_mtx;

	/*** Message buffer		  *************/
	API_CRE_MBF	intfc_cre_mbf;
	API_ACRE_MBF	intfc_acre_mbf;
	API_DEL_MBF	intfc_del_mbf;
	API_SND_MBF	intfc_snd_mbf;
	API_PSND_MBF	intfc_psnd_mbf;
	API_TSND_MBF	intfc_tsnd_mbf;
	API_RCV_MBF	intfc_rcv_mbf;
	API_PRCV_MBF	intfc_prcv_mbf;
	API_TRCV_MBF	intfc_trcv_mbf;
	API_REF_MBF	intfc_ref_mbf;

/*** Memorypool management					***********/
	/*** Fixed-size			  *************/
	API_CRE_MPF	intfc_cre_mpf;
	API_ACRE_MPF	intfc_acre_mpf;
	API_DEL_MPF	intfc_del_mpf;
	API_GET_MPF	intfc_get_mpf;
	API_PGET_MPF	intfc_pget_mpf;
	API_TGET_MPF	intfc_tget_mpf;
	API_REL_MPF	intfc_rel_mpf;
	API_REF_MPF	intfc_ref_mpf;

	/*** Variable-size		  *************/
	API_CRE_MPL	intfc_cre_mpl;
	API_ACRE_MPL	intfc_acre_mpl;
	API_DEL_MPL	intfc_del_mpl;
	API_GET_MPL	intfc_get_mpl;
	API_PGET_MPL	intfc_pget_mpl;
	API_TGET_MPL	intfc_tget_mpl;
	API_REL_MPL	intfc_rel_mpl;
	API_REF_MPL	intfc_ref_mpl;

/*** Timer management						***********/
	/*** System time management ***********/
	API_SET_TIM	intfc_set_tim;
	API_GET_TIM	intfc_get_tim;

	/*** Cyclic handler		  *************/
	API_CRE_CYC	intfc_cre_cyc;
	API_ACRE_CYC	intfc_acre_cyc;
	API_DEL_CYC	intfc_del_cyc;
	API_STA_CYC	intfc_sta_cyc;
	API_STP_CYC	intfc_stp_cyc;
	API_REF_CYC	intfc_ref_cyc;

	/*** Alarm handler		  *************/
	API_CRE_ALM	intfc_cre_alm;
	API_ACRE_ALM	intfc_acre_alm;
	API_DEL_ALM	intfc_del_alm;
	API_STA_ALM	intfc_sta_alm;
	API_STP_ALM	intfc_stp_alm;
	API_REF_ALM	intfc_ref_alm;

	/*** Overrun handler	  *************/
	API_DEF_OVR	intfc_def_ovr;
	API_STA_OVR	intfc_sta_ovr;
	API_STP_OVR	intfc_stp_ovr;
	API_REF_OVR	intfc_ref_ovr;

/*** System status management				***********/
	API_ROT_RDQ	intfc_rot_rdq;
	API_GET_TID	intfc_get_tid;
	API_LOC_CPU	intfc_loc_cpu;
	API_UNL_CPU	intfc_unl_cpu;
	API_DIS_DSP	intfc_dis_dsp;
	API_ENA_DSP	intfc_ena_dsp;
	API_SNS_CTX	intfc_sns_ctx;
	API_SNS_LOC	intfc_sns_loc;
	API_SNS_DSP	intfc_sns_dsp;
	API_SNS_DPN	intfc_sns_dpn;
	API_VSYS_DWN	intfc_vsys_dwn;
	API_VGET_TRC	intfc_vget_trc;
	API_IVBGN_INT	intfc_ivbgn_int;
	API_IVEND_INT	intfc_ivend_int;

/*** Interrupt management					***********/
	API_DEF_INH	intfc_def_inh;
	API_CHG_IMS	intfc_chg_ims;
	API_GET_IMS	intfc_get_ims;

/*** Service call management				***********/
	API_DEF_SVC	intfc_def_svc;
	API_CAL_SVC	intfc_cal_svc;

/*** System construction management			***********/
	API_DEF_EXC	intfc_def_exc;
	API_VDEF_TRP	intfc_vdef_trp;
	API_REF_CFG	intfc_ref_cfg;
	API_REF_VER	intfc_ref_ver;

/*** Cache management						***********/
	API_VCLR_CAC	intfc_vclr_cac;
	API_VFLS_CAC	intfc_vfls_cac;
	API_VINV_CAC	intfc_vinv_cac;
	API_VINI_CAC	intfc_vini_cac;

/*** Debugger support SVC ***/
	API_DACT_TRC	intfc_dact_trc;
	API_DDEL_TSK	intfc_ddel_tsk;
	API_DSUS_TSK	intfc_dsus_tsk;
	API_DTER_TSK	intfc_dter_tsk;

/*** DSP standby management					***********/
	API_VCHG_COP	intfc_vchg_cop;

}CNFGTBL;

#pragma unpack
/****************************************************************************/
/*	  Service call API definition											*/
/****************************************************************************/
extern const CNFGTBL _kernel_cnfgtbl;
/*** Task management						***********/
	#define cre_tsk(tskid, pk_ctsk)	(_kernel_cnfgtbl.intfc_cre_tsk)(tskid, pk_ctsk)
	#define acre_tsk(pk_ctsk)	(_kernel_cnfgtbl.intfc_acre_tsk)(pk_ctsk)
	#define vscr_tsk(tskid, pk_ctsk)	(_kernel_cnfgtbl.intfc_vscr_tsk)(tskid, pk_ctsk)
	#define del_tsk(tskid)	(_kernel_cnfgtbl.intfc_del_tsk)(tskid)
	#define act_tsk(tskid)	(_kernel_cnfgtbl.intfc_act_tsk)(tskid)
	#define can_act(tskid)	(_kernel_cnfgtbl.intfc_can_act)(tskid)
	#define sta_tsk(tskid, stacd)	(_kernel_cnfgtbl.intfc_sta_tsk)(tskid, stacd)
	#define ext_tsk()	(_kernel_cnfgtbl.intfc_ext_tsk)()
	#define exd_tsk()	(_kernel_cnfgtbl.intfc_exd_tsk)()
	#define ter_tsk(tskid)	(_kernel_cnfgtbl.intfc_ter_tsk)(tskid)
	#define chg_pri(tskid, tskpri)	(_kernel_cnfgtbl.intfc_chg_pri)(tskid, tskpri)
	#define get_pri(tskid, p_tskpri)	(_kernel_cnfgtbl.intfc_get_pri)(tskid, p_tskpri)
	#define ref_tsk(tskid, pk_rtsk)	(_kernel_cnfgtbl.intfc_ref_tsk)(tskid, pk_rtsk)
	#define ref_tst(tskid, pk_rtst)	(_kernel_cnfgtbl.intfc_ref_tst)(tskid, pk_rtst)
	#define vchg_tmd(tmd)	(_kernel_cnfgtbl.intfc_vchg_tmd)(tmd)

	#define icre_tsk(tskid, pk_ctsk)	cre_tsk(tskid, pk_ctsk)
	#define iacre_tsk(pk_ctsk)	acre_tsk(pk_ctsk)
	#define ivscr_tsk(tskid, pk_ctsk)	vscr_tsk(tskid, pk_ctsk)
	#define iact_tsk(tskid)	act_tsk(tskid)
	#define ican_act(tskid)	can_act(tskid)
	#define ista_tsk(tskid, stacd)	sta_tsk(tskid, stacd)
	#define ichg_pri(tskid, tskpri)	chg_pri(tskid, tskpri)
	#define iget_pri(tskid, p_tskpri)	get_pri(tskid, p_tskpri)
	#define iref_tsk(tskid, pk_rtsk)	ref_tsk(tskid, pk_rtsk)
	#define iref_tst(tskid, pk_rtst)	ref_tst(tskid, pk_rtst)

/*** Task-dependent synchronization			***********/
	#define slp_tsk()	(_kernel_cnfgtbl.intfc_slp_tsk)()
	#define tslp_tsk(tmout)	(_kernel_cnfgtbl.intfc_tslp_tsk)(tmout)
	#define wup_tsk(tskid)	(_kernel_cnfgtbl.intfc_wup_tsk)(tskid)
	#define can_wup(tskid)	(_kernel_cnfgtbl.intfc_can_wup)(tskid)
	#define rel_wai(tskid)	(_kernel_cnfgtbl.intfc_rel_wai)(tskid)
	#define sus_tsk(tskid)	(_kernel_cnfgtbl.intfc_sus_tsk)(tskid)
	#define rsm_tsk(tskid)	(_kernel_cnfgtbl.intfc_rsm_tsk)(tskid)
	#define frsm_tsk(tskid)	(_kernel_cnfgtbl.intfc_frsm_tsk)(tskid)
	#define dly_tsk(dlytim)	(_kernel_cnfgtbl.intfc_dly_tsk)(dlytim)
	#define vset_tfl(tskid, setptn)	(_kernel_cnfgtbl.intfc_vset_tfl)(tskid, setptn)
	#define vclr_tfl(tskid, clrptn)	(_kernel_cnfgtbl.intfc_vclr_tfl)(tskid, clrptn)
	#define vwai_tfl(waiptn, p_tflptn)	(_kernel_cnfgtbl.intfc_vwai_tfl)(waiptn, p_tflptn)
	#define vpol_tfl(waiptn, p_tflptn)	(_kernel_cnfgtbl.intfc_vpol_tfl)(waiptn, p_tflptn)
	#define vtwai_tfl(waiptn, p_tflptn, tmout)	(_kernel_cnfgtbl.intfc_vtwai_tfl)(waiptn, p_tflptn, tmout)

	#define iwup_tsk(tskid)	wup_tsk(tskid)
	#define ican_wup(tskid)	can_wup(tskid)
	#define irel_wai(tskid)	rel_wai(tskid)
	#define isus_tsk(tskid)	sus_tsk(tskid)
	#define irsm_tsk(tskid)	rsm_tsk(tskid)
	#define ifrsm_tsk(tskid)	frsm_tsk(tskid)
	#define ivset_tfl(tskid, setptn)	vset_tfl(tskid, setptn)
	#define ivclr_tfl(tskid, clrptn)	vclr_tfl(tskid, clrptn)

/*** Task exception process					***********/
	#define def_tex(tskid, pk_dtex)	(_kernel_cnfgtbl.intfc_def_tex)(tskid, pk_dtex)
	#define ras_tex(tskid, rasptn)	(_kernel_cnfgtbl.intfc_ras_tex)(tskid, rasptn)
	#define dis_tex()	(_kernel_cnfgtbl.intfc_dis_tex)()
	#define ena_tex()	(_kernel_cnfgtbl.intfc_ena_tex)()
	#define sns_tex()	(_kernel_cnfgtbl.intfc_sns_tex)()
	#define ref_tex(tskid, pk_rtex)	(_kernel_cnfgtbl.intfc_ref_tex)(tskid, pk_rtex)

	#define idef_tex(tskid, pk_dtex)	def_tex(tskid, pk_dtex)
	#define iras_tex(tskid, rasptn)	ras_tex(tskid, rasptn)
	#define iref_tex(tskid, pk_rtex)	ref_tex(tskid, pk_rtex)

/*** Synchronization and communication		***********/
	/*** Semaphore			  *************/
	#define cre_sem(semid, pk_csem)	(_kernel_cnfgtbl.intfc_cre_sem)(semid, pk_csem)
	#define acre_sem(pk_csem)	(_kernel_cnfgtbl.intfc_acre_sem)(pk_csem)
	#define del_sem(semid)	(_kernel_cnfgtbl.intfc_del_sem)(semid)
	#define sig_sem(semid)	(_kernel_cnfgtbl.intfc_sig_sem)(semid)
	#define wai_sem(semid)	(_kernel_cnfgtbl.intfc_wai_sem)(semid)
	#define pol_sem(semid)	(_kernel_cnfgtbl.intfc_pol_sem)(semid)
	#define twai_sem(semid, tmout)	(_kernel_cnfgtbl.intfc_twai_sem)(semid, tmout)
	#define ref_sem(semid, pk_rsem)	(_kernel_cnfgtbl.intfc_ref_sem)(semid, pk_rsem)

	#define icre_sem(semid, pk_csem)	cre_sem(semid, pk_csem)
	#define iacre_sem(pk_csem)	acre_sem(pk_csem)
	#define isig_sem(semid)	sig_sem(semid)
	#define ipol_sem(semid)	pol_sem(semid)
	#define iref_sem(semid, pk_rsem)	ref_sem(semid, pk_rsem)

	/*** Eventflag			  *************/
	#define cre_flg(flgid, pk_cflg)	(_kernel_cnfgtbl.intfc_cre_flg)(flgid, pk_cflg)
	#define acre_flg(pk_cflg)	(_kernel_cnfgtbl.intfc_acre_flg)(pk_cflg)
	#define del_flg(flgid)	(_kernel_cnfgtbl.intfc_del_flg)(flgid)
	#define set_flg(flgid, setptn)	(_kernel_cnfgtbl.intfc_set_flg)(flgid, setptn)
	#define clr_flg(flgid, clrptn)	(_kernel_cnfgtbl.intfc_clr_flg)(flgid, clrptn)
	#define wai_flg(flgid, waiptn, wfmode, p_flgptn)	(_kernel_cnfgtbl.intfc_wai_flg)(flgid, waiptn, wfmode, p_flgptn)
	#define pol_flg(flgid, waiptn, wfmode, p_flgptn)	(_kernel_cnfgtbl.intfc_pol_flg)(flgid, waiptn, wfmode, p_flgptn)
	#define twai_flg(flgid, waiptn, wfmode, p_flgptn, tmout)	(_kernel_cnfgtbl.intfc_twai_flg)(flgid, waiptn, wfmode, p_flgptn, tmout)
	#define ref_flg(flgid, pk_rflg)	(_kernel_cnfgtbl.intfc_ref_flg)(flgid, pk_rflg)

	#define icre_flg(flgid, pk_cflg)	cre_flg(flgid, pk_cflg)
	#define iacre_flg(pk_cflg)	acre_flg(pk_cflg)
	#define iset_flg(flgid, setptn)	set_flg(flgid, setptn)
	#define iclr_flg(flgid, clrptn)	clr_flg(flgid, clrptn)
	#define ipol_flg(flgid, waiptn, wfmode, p_flgptn)	pol_flg(flgid, waiptn, wfmode, p_flgptn)
	#define iref_flg(flgid, pk_rflg)	ref_flg(flgid, pk_rflg)

	/*** Data queue			  *************/
	#define cre_dtq(dtqid, pk_cdtq)	(_kernel_cnfgtbl.intfc_cre_dtq)(dtqid, pk_cdtq)
	#define acre_dtq(pk_cdtq)	(_kernel_cnfgtbl.intfc_acre_dtq)(pk_cdtq)
	#define del_dtq(dtqid)	(_kernel_cnfgtbl.intfc_del_dtq)(dtqid)
	#define snd_dtq(dtqid, data)	(_kernel_cnfgtbl.intfc_snd_dtq)(dtqid, data)
	#define psnd_dtq(dtqid, data)	(_kernel_cnfgtbl.intfc_psnd_dtq)(dtqid, data)
	#define tsnd_dtq(dtqid, data, tmout)	(_kernel_cnfgtbl.intfc_tsnd_dtq)(dtqid, data, tmout)
	#define fsnd_dtq(dtqid, data)	(_kernel_cnfgtbl.intfc_fsnd_dtq)(dtqid, data)
	#define rcv_dtq(dtqid, p_data)	(_kernel_cnfgtbl.intfc_rcv_dtq)(dtqid, p_data)
	#define prcv_dtq(dtqid, p_data)	(_kernel_cnfgtbl.intfc_prcv_dtq)(dtqid, p_data)
	#define trcv_dtq(dtqid, p_data, tmout)	(_kernel_cnfgtbl.intfc_trcv_dtq)(dtqid, p_data, tmout)
	#define ref_dtq(dtqid, pk_rdtq)	(_kernel_cnfgtbl.intfc_ref_dtq)(dtqid, pk_rdtq)

	#define icre_dtq(dtqid, pk_cdtq)	cre_dtq(dtqid, pk_cdtq)
	#define iacre_dtq(pk_cdtq)	acre_dtq(pk_cdtq)
	#define ipsnd_dtq(dtqid, data)	psnd_dtq(dtqid, data)
	#define ifsnd_dtq(dtqid, data)	fsnd_dtq(dtqid, data)
	#define iref_dtq(dtqid, pk_rdtq)	ref_dtq(dtqid, pk_rdtq)

	/*** Mailbox			  *************/
	#define cre_mbx(mbxid, pk_cmbx)	(_kernel_cnfgtbl.intfc_cre_mbx)(mbxid, pk_cmbx)
	#define acre_mbx(pk_cmbx)	(_kernel_cnfgtbl.intfc_acre_mbx)(pk_cmbx)
	#define del_mbx(mbxid)	(_kernel_cnfgtbl.intfc_del_mbx)(mbxid)
	#define snd_mbx(mbxid, pk_msg)	(_kernel_cnfgtbl.intfc_snd_mbx)(mbxid, pk_msg)
	#define rcv_mbx(mbxid, ppk_msg)	(_kernel_cnfgtbl.intfc_rcv_mbx)(mbxid, ppk_msg)
	#define prcv_mbx(mbxid, ppk_msg)	(_kernel_cnfgtbl.intfc_prcv_mbx)(mbxid, ppk_msg)
	#define trcv_mbx(mbxid, ppk_msg, tmout)	(_kernel_cnfgtbl.intfc_trcv_mbx)(mbxid, ppk_msg, tmout)
	#define ref_mbx(mbxid, pk_rmbx)	(_kernel_cnfgtbl.intfc_ref_mbx)(mbxid, pk_rmbx)

	#define icre_mbx(mbxid, pk_cmbx)	cre_mbx(mbxid, pk_cmbx)
	#define iacre_mbx(pk_cmbx)	acre_mbx(pk_cmbx)
	#define isnd_mbx(mbxid, pk_msg)	snd_mbx(mbxid, pk_msg)
	#define iprcv_mbx(mbxid, ppk_msg)	prcv_mbx(mbxid, ppk_msg)
	#define iref_mbx(mbxid, pk_rmbx)	ref_mbx(mbxid, pk_rmbx)

	/*** Mutex				  *************/
	#define cre_mtx(mtxid, pk_cmtx)	(_kernel_cnfgtbl.intfc_cre_mtx)(mtxid, pk_cmtx)
	#define acre_mtx(pk_cmtx)	(_kernel_cnfgtbl.intfc_acre_mtx)(pk_cmtx)
	#define del_mtx(mtxid)	(_kernel_cnfgtbl.intfc_del_mtx)(mtxid)
	#define loc_mtx(mtxid)	(_kernel_cnfgtbl.intfc_loc_mtx)(mtxid)
	#define ploc_mtx(mtxid)	(_kernel_cnfgtbl.intfc_ploc_mtx)(mtxid)
	#define tloc_mtx(mtxid, tmout)	(_kernel_cnfgtbl.intfc_tloc_mtx)(mtxid, tmout)
	#define unl_mtx(mtxid)	(_kernel_cnfgtbl.intfc_unl_mtx)(mtxid)
	#define ref_mtx(mtxid, pk_rmtx)	(_kernel_cnfgtbl.intfc_ref_mtx)(mtxid, pk_rmtx)

	/*** Message buffer		  *************/
	#define cre_mbf(mbfid, pk_cmbf)	(_kernel_cnfgtbl.intfc_cre_mbf)(mbfid, pk_cmbf)
	#define acre_mbf(pk_cmbf)	(_kernel_cnfgtbl.intfc_acre_mbf)(pk_cmbf)
	#define del_mbf(mbfid)	(_kernel_cnfgtbl.intfc_del_mbf)(mbfid)
	#define snd_mbf(mbfid, msg, msgsz)	(_kernel_cnfgtbl.intfc_snd_mbf)(mbfid, msg, msgsz)
	#define psnd_mbf(mbfid, msg, msgsz)	(_kernel_cnfgtbl.intfc_psnd_mbf)(mbfid, msg, msgsz)
	#define tsnd_mbf(mbfid, msg, msgsz, tmout)	(_kernel_cnfgtbl.intfc_tsnd_mbf)(mbfid, msg, msgsz, tmout)
	#define rcv_mbf(mbfid, msg)	(_kernel_cnfgtbl.intfc_rcv_mbf)(mbfid, msg)
	#define prcv_mbf(mbfid, msg)	(_kernel_cnfgtbl.intfc_prcv_mbf)(mbfid, msg)
	#define trcv_mbf(mbfid, msg, tmout)	(_kernel_cnfgtbl.intfc_trcv_mbf)(mbfid, msg, tmout)
	#define ref_mbf(mbfid, pk_rmbf)	(_kernel_cnfgtbl.intfc_ref_mbf)(mbfid, pk_rmbf)

	#define icre_mbf(mbfid, pk_cmbf)	cre_mbf(mbfid, pk_cmbf)
	#define iacre_mbf(pk_cmbf)	acre_mbf(pk_cmbf)
	#define ipsnd_mbf(mbfid, msg, msgsz)	psnd_mbf(mbfid, msg, msgsz)
	#define iref_mbf(mbfid, pk_rmbf)	ref_mbf(mbfid, pk_rmbf)

/*** Memorypool management					***********/
	/*** Fixed-size			  *************/
	#define cre_mpf(mpfid, pk_cmpf)	(_kernel_cnfgtbl.intfc_cre_mpf)(mpfid, pk_cmpf)
	#define acre_mpf(pk_cmpf)	(_kernel_cnfgtbl.intfc_acre_mpf)(pk_cmpf)
	#define del_mpf(mpfid)	(_kernel_cnfgtbl.intfc_del_mpf)(mpfid)
	#define get_mpf(mpfid, p_blk)	(_kernel_cnfgtbl.intfc_get_mpf)(mpfid, p_blk)
	#define pget_mpf(mpfid, p_blk)	(_kernel_cnfgtbl.intfc_pget_mpf)(mpfid, p_blk)
	#define tget_mpf(mpfid, p_blk, tmout)	(_kernel_cnfgtbl.intfc_tget_mpf)(mpfid, p_blk, tmout)
	#define rel_mpf(mpfid, blk)	(_kernel_cnfgtbl.intfc_rel_mpf)(mpfid, blk)
	#define ref_mpf(mpfid, pk_rmpf)	(_kernel_cnfgtbl.intfc_ref_mpf)(mpfid, pk_rmpf)

	#define icre_mpf(mpfid, pk_cmpf)	cre_mpf(mpfid, pk_cmpf)
	#define iacre_mpf(pk_cmpf)	acre_mpf(pk_cmpf)
	#define ipget_mpf(mpfid, p_blk)	pget_mpf(mpfid, p_blk)
	#define irel_mpf(mpfid, blk)	rel_mpf(mpfid, blk)
	#define iref_mpf(mpfid, pk_rmpf)	ref_mpf(mpfid, pk_rmpf)

	/*** Variable-size		  *************/
	#define cre_mpl(mplid, pk_cmpl)	(_kernel_cnfgtbl.intfc_cre_mpl)(mplid, pk_cmpl)
	#define acre_mpl(pk_cmpl)	(_kernel_cnfgtbl.intfc_acre_mpl)(pk_cmpl)
	#define del_mpl(mplid)	(_kernel_cnfgtbl.intfc_del_mpl)(mplid)
	#define get_mpl(mplid, blksz, p_blk)	(_kernel_cnfgtbl.intfc_get_mpl)(mplid, blksz, p_blk)
	#define pget_mpl(mplid, blksz, p_blk)	(_kernel_cnfgtbl.intfc_pget_mpl)(mplid, blksz, p_blk)
	#define tget_mpl(mplid, blksz, p_blk, tmout)	(_kernel_cnfgtbl.intfc_tget_mpl)(mplid, blksz, p_blk, tmout)
	#define rel_mpl(mplid, blk)	(_kernel_cnfgtbl.intfc_rel_mpl)(mplid, blk)
	#define ref_mpl(mplid, pk_rmpl)	(_kernel_cnfgtbl.intfc_ref_mpl)(mplid, pk_rmpl)

	#define icre_mpl(mplid, pk_cmpl)	cre_mpl(mplid, pk_cmpl)
	#define iacre_mpl(pk_cmpl)	acre_mpl(pk_cmpl)
	#define ipget_mpl(mplid, blksz, p_blk)	pget_mpl(mplid, blksz, p_blk)
	#define irel_mpl(mplid, blk)	rel_mpl(mplid, blk)
	#define iref_mpl(mplid, pk_rmpl)	ref_mpl(mplid, pk_rmpl)

/*** Timer management						***********/
	/*** System time management ***********/
	#define set_tim(p_systim)	(_kernel_cnfgtbl.intfc_set_tim)(p_systim)
	#define get_tim(p_systim)	(_kernel_cnfgtbl.intfc_get_tim)(p_systim)

	#define iset_tim(p_systim)	set_tim(p_systim)
	#define iget_tim(p_systim)	get_tim(p_systim)

	/*** Cyclic handler		  *************/
	#define cre_cyc(cycid, pk_ccyc)	(_kernel_cnfgtbl.intfc_cre_cyc)(cycid, pk_ccyc)
	#define acre_cyc(pk_ccyc)	(_kernel_cnfgtbl.intfc_acre_cyc)(pk_ccyc)
	#define del_cyc(cycid)	(_kernel_cnfgtbl.intfc_del_cyc)(cycid)
	#define sta_cyc(cycid)	(_kernel_cnfgtbl.intfc_sta_cyc)(cycid)
	#define stp_cyc(cycid)	(_kernel_cnfgtbl.intfc_stp_cyc)(cycid)
	#define ref_cyc(cycid, pk_rcyc)	(_kernel_cnfgtbl.intfc_ref_cyc)(cycid, pk_rcyc)

	#define icre_cyc(cycid, pk_ccyc)	cre_cyc(cycid, pk_ccyc)
	#define iacre_cyc(pk_ccyc)	acre_cyc(pk_ccyc)
	#define ista_cyc(cycid)	sta_cyc(cycid)
	#define istp_cyc(cycid)	stp_cyc(cycid)
	#define iref_cyc(cycid, pk_rcyc)	ref_cyc(cycid, pk_rcyc)

	/*** Alarm handler		  *************/
	#define cre_alm(almid, pk_calm)	(_kernel_cnfgtbl.intfc_cre_alm)(almid, pk_calm)
	#define acre_alm(pk_calm)	(_kernel_cnfgtbl.intfc_acre_alm)(pk_calm)
	#define del_alm(almid)	(_kernel_cnfgtbl.intfc_del_alm)(almid)
	#define sta_alm(almid, almtim)	(_kernel_cnfgtbl.intfc_sta_alm)(almid, almtim)
	#define stp_alm(almid)	(_kernel_cnfgtbl.intfc_stp_alm)(almid)
	#define ref_alm(almid, pk_ralm)	(_kernel_cnfgtbl.intfc_ref_alm)(almid, pk_ralm)

	#define icre_alm(almid, pk_calm)	cre_alm(almid, pk_calm)
	#define iacre_alm(pk_calm)	acre_alm(pk_calm)
	#define ista_alm(almid, almtim)	sta_alm(almid, almtim)
	#define istp_alm(almid)	stp_alm(almid)
	#define iref_alm(almid, pk_ralm)	ref_alm(almid, pk_ralm)

	/*** Overrun handler	  *************/
	#define def_ovr(pk_dovr)	(_kernel_cnfgtbl.intfc_def_ovr)(pk_dovr)
	#define sta_ovr(tskid, ovrtim)	(_kernel_cnfgtbl.intfc_sta_ovr)(tskid, ovrtim)
	#define stp_ovr(tskid)	(_kernel_cnfgtbl.intfc_stp_ovr)(tskid)
	#define ref_ovr(tskid, pk_rovr)	(_kernel_cnfgtbl.intfc_ref_ovr)(tskid, pk_rovr)

	#define ista_ovr(tskid, ovrtim)	sta_ovr(tskid, ovrtim)
	#define istp_ovr(tskid)	stp_ovr(tskid)
	#define iref_ovr(tskid, pk_rovr)	ref_ovr(tskid, pk_rovr)

/*** System status management				***********/
	#define rot_rdq(tskpri)	(_kernel_cnfgtbl.intfc_rot_rdq)(tskpri)
	#define get_tid(p_tskid)	(_kernel_cnfgtbl.intfc_get_tid)(p_tskid)
	#define loc_cpu()	(_kernel_cnfgtbl.intfc_loc_cpu)()
	#define unl_cpu()	(_kernel_cnfgtbl.intfc_unl_cpu)()
	#define dis_dsp()	(_kernel_cnfgtbl.intfc_dis_dsp)()
	#define ena_dsp()	(_kernel_cnfgtbl.intfc_ena_dsp)()
	#define sns_ctx()	(_kernel_cnfgtbl.intfc_sns_ctx)()
	#define sns_loc()	(_kernel_cnfgtbl.intfc_sns_loc)()
	#define sns_dsp()	(_kernel_cnfgtbl.intfc_sns_dsp)()
	#define sns_dpn()	(_kernel_cnfgtbl.intfc_sns_dpn)()
	#define vsys_dwn(type, ercd, inf1, inf2)	(_kernel_cnfgtbl.intfc_vsys_dwn)(type, ercd, inf1, inf2)
	#define vget_trc(para1, para2, para3, para4)	(_kernel_cnfgtbl.intfc_vget_trc)(para1, para2, para3, para4)
	#define ivbgn_int(dintno)	(_kernel_cnfgtbl.intfc_ivbgn_int)(dintno)
	#define ivend_int(dintno)	(_kernel_cnfgtbl.intfc_ivend_int)(dintno)
	#ifdef __cplusplus
	extern "C"{
	#endif
	extern void _kernel_reset(void);
	#ifdef __cplusplus
	}
	#endif
	#define vsta_knl() _kernel_reset()

	#define irot_rdq(tskpri)	rot_rdq(tskpri)
	#define iget_tid(p_tskid)	get_tid(p_tskid)
	#define iloc_cpu()	loc_cpu()
	#define iunl_cpu()	unl_cpu()
	#define ivsys_dwn(type, ercd, inf1, inf2)	vsys_dwn(type, ercd, inf1, inf2)
	#define ivget_trc(para1, para2, para3, para4)	vget_trc(para1, para2, para3, para4)
	#define ivsta_knl() vsta_knl()

/*** Interrupt management					***********/
	#define def_inh(inhno, pk_dinh)	(_kernel_cnfgtbl.intfc_def_inh)(inhno, pk_dinh)
	#define chg_ims(imask)	(_kernel_cnfgtbl.intfc_chg_ims)(imask)
	#define get_ims(p_imask)	(_kernel_cnfgtbl.intfc_get_ims)(p_imask)

	#define idef_inh(inhno, pk_dinh)	def_inh(inhno, pk_dinh)
	#define ichg_ims(imask)	chg_ims(imask)
	#define iget_ims(p_imask)	get_ims(p_imask)

/*** Service call management				***********/
	#define def_svc(fncd, pk_dsvc)	(_kernel_cnfgtbl.intfc_def_svc)(fncd, pk_dsvc)
	#define cal_svc		_kernel_cnfgtbl.intfc_cal_svc

	#define idef_svc(fncd, pk_dsvc)	def_svc(fncd, pk_dsvc)
	#define ical_svc	cal_svc

/*** System construction management			***********/
	#define def_exc(excno, pk_dexc)	(_kernel_cnfgtbl.intfc_def_exc)(excno, pk_dexc)
	#define vdef_trp(dtrpno, pk_dtrp)	(_kernel_cnfgtbl.intfc_vdef_trp)(dtrpno, pk_dtrp)
	#define ref_cfg(pk_rcfg)	(_kernel_cnfgtbl.intfc_ref_cfg)(pk_rcfg)
	#define ref_ver(pk_rver)	(_kernel_cnfgtbl.intfc_ref_ver)(pk_rver)

	#define idef_exc(excno, pk_dexc)	def_exc(excno, pk_dexc)
	#define ivdef_trp(dtrpno, pk_dtrp)	vdef_trp(dtrpno, pk_dtrp)
	#define iref_cfg(pk_rcfg)	ref_cfg(pk_rcfg)
	#define iref_ver(pk_rver)	ref_ver(pk_rver)

/*** Cache management						***********/
#ifdef _SH4ALDSP
    #define vclr_cac(clradr1, clradr2, mode)  (_kernel_cnfgtbl.intfc_vclr_cac)(clradr1, clradr2, mode)
#else
	#define vclr_cac(clradr1, clradr2)	(_kernel_cnfgtbl.intfc_vclr_cac)(clradr1, clradr2)
#endif

	#define vfls_cac(flsadr1, flsadr2)	(_kernel_cnfgtbl.intfc_vfls_cac)(flsadr1, flsadr2)

#ifdef _SH4ALDSP
    #define vinv_cac(invadr1, invadr2, mode)  (_kernel_cnfgtbl.intfc_vinv_cac)(invadr1, invadr2, mode)
#else
	#define vinv_cac()	(_kernel_cnfgtbl.intfc_vinv_cac)()
#endif

#ifdef _SH4ALDSP
    #define vini_cac(cacatr)  (_kernel_cnfgtbl.intfc_vini_cac)(cacatr)
#else
	#define vini_cac(ccr_data, entnum, waynum)	(_kernel_cnfgtbl.intfc_vini_cac)(ccr_data, entnum, waynum)
#endif

#ifdef _SH4ALDSP
    #define ivclr_cac(clradr1, clradr2, mode) vclr_cac(clradr1, clradr2, mode)
#else
	#define ivclr_cac(clradr1, clradr2)	vclr_cac(clradr1, clradr2)
#endif

	#define ivfls_cac(flsadr1, flsadr2)	vfls_cac(flsadr1, flsadr2)

#ifdef _SH4ALDSP
    #define ivinv_cac(invadr1, invadr2, mode) vinv_cac(invadr1, invadr2, mode)
#else
	#define ivinv_cac()	vinv_cac()
#endif

#ifdef _SH4ALDSP
    #define ivini_cac(cacatr) vini_cac(cacatr)
#else
	#define ivini_cac(ccr_data, entnum, waynum)	vini_cac(ccr_data, entnum, waynum)
#endif

/*** Debugger support SVC ***/
	#define dact_trc(trcact, trcbuf, trcent)	(_kernel_cnfgtbl.intfc_dact_trc)(trcact, trcbuf, trcent)
	#define ddel_tsk(tskid)	(_kernel_cnfgtbl.intfc_ddel_tsk)(tskid)
	#define dsus_tsk(tskid, ignore)	(_kernel_cnfgtbl.intfc_dsus_tsk)(tskid, ignore)
	#define dter_tsk(tskid, ignore)	(_kernel_cnfgtbl.intfc_dter_tsk)(tskid, ignore)

/*** DSP standby management					***********/
	#define vchg_cop(atr)	(_kernel_cnfgtbl.intfc_vchg_cop)(atr)

#endif
