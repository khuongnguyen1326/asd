/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : timer.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"
#include "led.h"
#include "uart.h"

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
void init_LED(void);
char dec_to_hex(uint16_t);
void trans_LED(uint16_t);
void LED(char,char,char);
/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/


/***********************************************************************************************************************
* Function Name: init_LED
* Description  : Initialise led port mode
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void init_LED(){
	
	PM4=0; PM6=0;
	PM10=0; 
	ADPC=1;
	PM15_bit.no2=0;
	PM10_bit.no1=0;
	PM1=0xFE;
	P6=0xFF;
	P4=0xFF;
	P15_bit.no2=1;
	P10_bit.no1=1;
	P1_bit.no0=0;

}

/***********************************************************************************************************************
* Function Name: dec_to_hex
* Description  : this function transform character from decimal to hexa
* Arguments    : uint16_t value
* Return Value : this fucntion return character in hexa type
***********************************************************************************************************************/
char dec_to_hex(uint16_t value){
	if((value>=0)&&(value<=9)){
		return (char) value + 48;
	}
	else{
		return (char) value + 55;
	}
}


/***********************************************************************************************************************
* Function Name: trans_LED
* Description  : change value of trans_led_buff to display LED status
* Arguments    : uint16_t value
* Return Value : None
***********************************************************************************************************************/

void trans_LED(uint16_t value){
	uint16_t temp;
	
	//Get bit 15-12
	temp = value >> 12;
	temp = temp & 0x0F;
	trans_led_buff[7] = dec_to_hex(temp);
	
	//get bit 11-8
	temp = value >> 8;
	temp = temp & 0x0F;
	trans_led_buff[8] = dec_to_hex(temp);
	
	//get bit 7-4
	temp = value >> 4;
	temp = temp & 0x0F;
	trans_led_buff[9]= dec_to_hex(temp);
	
	//get bit 3-0
	temp = value;
	temp = temp & 0x0F;
	trans_led_buff[10] = dec_to_hex(temp);
		
}


/***********************************************************************************************************************
* Function Name: LED
* Description  : To check status of LED and change the status
* Arguments    : char a(first number of led), char i (second number of led), char status
* Return Value : None
***********************************************************************************************************************/

void LED(char a,char i,char status){
if(a==0){
	//LED 3
	if(i=='3'){
		if(status == '1'){
			P6_bit.no2 = 0;
			led_value = led_value | 0x0001;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P6_bit.no2 = 1;
			led_value = led_value &0xFFFE;
			trans_LED(led_value);
		}
	}
	//LED 4
	if(i=='4'){
		if(status == '1'){
			P4_bit.no2 = 0;
			led_value = led_value | 0x0002;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P4_bit.no2 = 1;
			led_value = led_value &0xFFFD;
			trans_LED(led_value);
		}
	}
	//LED 5
	if(i=='5'){
		if(status == '1'){
			P6_bit.no3 = 0;
			led_value = led_value | 0x0004;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P6_bit.no3 = 1;
			led_value = led_value &0xFFFB;
			trans_LED(led_value);
		}
	}
	//LED 6
	if(i=='6'){
		if(status == '1'){
			P4_bit.no3 = 0;
			led_value = led_value | 0x0008;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P4_bit.no3 = 1;
			led_value = led_value &0xFFF7;
			trans_LED(led_value);
		}
	}
	//LED 7
	if(i=='7'){
		if(status == '1'){
			P6_bit.no4 = 0;
			led_value = led_value | 0x0010;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P6_bit.no4 = 1;
			led_value = led_value &0xFFEF;
			trans_LED(led_value);
		}
	}
	//LED 8
	if(i=='8'){
		if(status == '1'){
			P4_bit.no4 = 0;
			led_value = led_value | 0x0020;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P4_bit.no4 = 1;
			led_value = led_value &0xFFDF;
			trans_LED(led_value);
		}
	}
	//LED 9
	if(i=='9'){
		if(status == '1'){
			P6_bit.no5 = 0;
			led_value = led_value | 0x0040;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P6_bit.no5 = 1;
			led_value = led_value &0xFFBF;
			trans_LED(led_value);
		}
	}
}
if(a==1){
	//LED 10
	if(i=='0'){
		if(status == '1'){
			P4_bit.no5 = 0;
			led_value = led_value | 0x0080;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P4_bit.no5 = 1;
			led_value = led_value &0xFF7F;
			trans_LED(led_value);
		}
	}
	//LED 11
	if(i=='1'){
		if(status == '1'){
			P6_bit.no6 = 0;
			led_value = led_value | 0x0100;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P6_bit.no6 = 1;
			led_value = led_value &0xFEFF;
			trans_LED(led_value);
		}
	}
	//LED 12
	if(i=='2'){
		if(status == '1'){
			P15_bit.no2 = 0;
			led_value = led_value | 0x0200;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P15_bit.no2 = 1;
			led_value = led_value &0xFDFF;
			trans_LED(led_value);
		}
	}
	//LED 13
	if(i=='3'){
		if(status == '1'){
			P6_bit.no7 = 0;
			led_value = led_value | 0x0400;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P6_bit.no7 = 1;
			led_value = led_value &0xFBFF;
			trans_LED(led_value);
		}
	}
	//LED 14
	if(i=='4'){
		if(status == '1'){
			P10_bit.no1 = 0;
			led_value = led_value | 0x0800;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P10_bit.no1 = 1;
			led_value = led_value &0xF7FF;
			trans_LED(led_value);
		}
	}
	//LED 15
	if(i=='5'){
		if(status == '1'){
			P4_bit.no1 = 0;
			led_value = led_value | 0x1000;
			trans_LED(led_value);
		}
		else if(status == '0'){
			P4_bit.no1 = 1;
			led_value = led_value &0xEFFF;
			trans_LED(led_value);
		}
	}
}
}