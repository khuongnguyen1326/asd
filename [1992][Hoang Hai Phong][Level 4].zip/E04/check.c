/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : timer.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"
#include "led.h"
#include "uart.h"
#include "adc.h"
#include "lcd.h"
#include "string.h"
/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
uint8_t check_valid_no_led(char *text);
uint8_t check_valid_text(char *text);
uint8_t check_length(char *text);
void fix_trans_buff(void);
void excute(void);
uint16_t num=0;
/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
* Function Name: excute
* Description  : Excute received data
* Arguments    : none
* Return Value : none
******************************************************************************/
void excute(){
	unsigned char LCD_Line = 1;
	int i,j;
	//check length error
	while(num!=pos){
		if(check_length(&rx_buff[num][0])==1){
			//Excute led data
				if(rx_buff[num][0]=='L'){
					//check number led error
					if(check_valid_no_led(&rx_buff[num][0])==1){
						if(rx_buff[num][3]==','){
							LED(0,rx_buff[num][2],rx_buff[num][4]);
						}
						else{
							LED(1,rx_buff[num][3],rx_buff[num][5]);
						}
						Uart_Transmit(trans_led_buff,12);
					}
					else{
						//Display if error
						if(error_flag==0){
							error_flag = 1;
							DisplayLCD(LCD_LINE8, (uint8_t *)"Msg Err");
						}
						fix_trans_buff();
						P1_bit.no0 = 1;
					}
				}
			//Excute text data
				else if(rx_buff[num][0]=='T'){
					//check text error
					if(check_valid_text(&rx_buff[num][0])==1){
						for(i=0;i<=12;i++){
							trans_text[i]=' ';
						}
						//Initialise string to display
						trans_text[14]='\0';
						LCD_Line = (uint8_t) rx_buff[num][2] - 48;
						for (i=0;i<=UART_RX_BUFFER_LEN;i++){
							if(rx_buff[num][i]=='^'){
								break;
							}
							else{
								trans_text[i]=rx_buff[num][i];
							}
						}
//						//Clear row below
//						for (j=LCD_Line;j<=8;j++){
//							DisplayLCD(LCD_LINE1 + j*8, (uint8_t *)"            ");
//						}
						
						/* Display text to LCD */
						DisplayLCD(LCD_LINE1 + (LCD_Line-1)*8, (uint8_t *)(&trans_text[4]));
					}
					else{
						//Display if error
						if(error_flag==0){
							error_flag = 1;
							DisplayLCD(LCD_LINE8, (uint8_t *)"Msg Err");
						}
						fix_trans_buff();
						P1_bit.no0 = 1;
					}
				}
				else{
					//Display if error
					if(error_flag==0){
						error_flag = 1;
						DisplayLCD(LCD_LINE8, (uint8_t *)"Msg Err");
					}
					fix_trans_buff();
					P1_bit.no0 = 1;
				}
			}
		else{
			//Display if error
			rx_count = 0;
			if(error_flag==0){
				error_flag = 1;
				DisplayLCD(LCD_LINE8, (uint8_t *)"Msg Err");
			}
			P1_bit.no0 = 1;
			fix_trans_buff();
		}
		num++;
		if(num==10) num = 0;
	}
}

/******************************************************************************
* Function Name: fix_trans_buff
* Description  : To fix transfer buffer after error
* Arguments    : none
* Return Value : none
******************************************************************************/
void fix_trans_buff(){
	strcpy(trans_led_buff,"$1992,L0000^");
	trans_LED(led_value);
	strcpy(trans_analog_buff,"$1992,A000^");
	trans_analog_buff[7]= (char) (gADC_Result/100) + 48;
	trans_analog_buff[8]= (char) ((gADC_Result/10)%10) + 48;
	trans_analog_buff[9]= (char) (gADC_Result%10) + 48;
}

/******************************************************************************
* Function Name: check_length
* Description  : To check length of received data
* Arguments    : received buffer
* Return Value : none
******************************************************************************/
uint8_t check_length(char *text){
uint8_t i;
uint8_t count=0;
	for (i=0; (text[i]!='^')&&(i<30);i++){
		count++;
	}
	if(count>25) return 0;
	 else{
		count = 0;
	 	for(i=4;(text[i]!='^')&&(i<30);i++){
			count++;
		}
		if(count>19) return 0;
		else return 1;
	 }
}

/******************************************************************************
* Function Name: check_valid_no_led
* Description  : To check invalid of led number in received data
* Arguments    : received buffer
* Return Value : none
******************************************************************************/
uint8_t check_valid_no_led(char *text){
uint8_t i;
uint8_t count=0;
	//calculate length of buffer
	for(i=0;text[i]!='^';i++){
		count++;
	}
	if((count!=5)&&(count!=6)) return 0;
	//if led = 10->15
	if(count==6){
		if(text[1]!=',') return 0;
		if(text[2]!='1') return 0;
		if((text[3]<'0')||(text[3]>'5')) return 0;
		if(text[4]!=',') return 0;
		if((text[5]!='0')&&(text[5]!='1')) return 0;
	}
	//if led = 3->9
	if(count==5){
		if(text[1]!=',') return 0;
		if((text[2]<'0')||(text[2]>'9')) return 0;
		if(text[3]!=',') return 0;
		if((text[4]!='0')&&(text[4]!='1')) return 0;
	}
return 1;
}

/******************************************************************************
* Function Name: check_valid_text
* Description  : To check invalid text of received data
* Arguments    : received buffer
* Return Value : none
******************************************************************************/
uint8_t check_valid_text(char *text){
uint8_t i;
	//text has value in [a..z] or [A..Z] or [0..9] or space, underline
	if((text[2]>'0')&&(text[2]<'9')&&(text[3]==',')){
		for(i=4;text[i]!='^';i++){
			if( ((text[i]>='a')&&(text[i]<='z'))
			  ||((text[i]>='A')&&(text[i]<='Z'))
			  ||((text[i]>='0')&&(text[i]<='9'))
			  ||(text[i]==' '))
			{
			  
				//do nothing  
			}
			else return 0;
		}
	}
	else return 0;
return 1;
}

