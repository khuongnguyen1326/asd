/****************************************************************************
 * Product Name : HI7700/4
 *   Copyright (c) 2000(2005) Renesas Technology Corp.
 *   and Renesas Solutions Corp. All rights reserved.
 * File Name : kernel_opttmr_tbl.h
 * File Version : 20050512
 ****************************************************************************/
#ifndef _HIOS_KERNEL_OPTTMR_TBL_H
#define _HIOS_KERNEL_OPTTMR_TBL_H

/****************************************************************************/
/*          TMU_INITBL (ROM/hidef)                                          */
/****************************************************************************/
#pragma pack 4

typedef struct tmu_initbl {
        UW     ini_longticrate;         /* user setting information         */
        UW     ini_tcr;                 /* TCRn data                        */
        UW     ini_timintlvl;           /* timer interrupt level(=knlmsklvl)*/
        UW     ini_ch0_tcnt;            /* TCOR0,TCNT0 data                 */
        UW     ini_ch1_tcnt;            /* TCOR1,TCNT1 data                 */
        UW     ini_ch2_tcnt_1msec;      /* TCNT2 suitable data of [1ms]     */
        UW     ini_ch2_tcnt_maxmsec;    /* TCNT2 max data                   */
        UW     ini_ch2_maxmsec;         /* TCNT2 setting max time           */
        UW     ini_pclock;              /* P clock                          */
        UW     ini_tmubaseadr;          /* TMU base address(=TOCR address)  */
        UW     ini_ipradr;              /* IPR address                      */
#ifdef _SH4ALDSP
        UW     ini_imcradr;             /* IMCR address                     */
#endif
        UW     ini_stbcradr;            /* STBCR address                    */
        UW     ini_def_ovr;             /* def_ovr SVC select(USE/NOTUSE)   */
} TMU_INITBL;

/****************************************************************************/
/*          TMU_DRVCB (RAM/hiwrk)                                           */
/****************************************************************************/
typedef struct tmu_drvcb {
        UW     dv_ch0tcnt;              /* anticipation time of CH0         */
        ID     dv_curid;                /* current id                       */
        VH     dv_rsv;                  /* (rsv)                            */
} TMU_DRVCB;

/****************************************************************************/
/*          TMU_CH2CB (RAM/hiwrk)                                           */
/****************************************************************************/
typedef struct tmu_ch2cb {
        UW     c2_tcntnum;              /* TCNT2 setting count              */
        UW     c2_surpus;               /* TCNT2 setting value(surplus)     */
} TMU_CH2CB;

/****************************************************************************/
/*          TMU_DRVMT (ROM/hicfg)                                           */
/****************************************************************************/
typedef struct tmu_drvmt {
        TMU_DRVCB *dm_drvcb;            /* address of DRVCB                 */
        TMU_CH2CB *dm_ch2cb;            /* address of CH2CB                 */
} TMU_DRVMT;

#pragma unpack

#define _kernel_tmu_drvmt NADR

#ifdef OPTTMR
#define _kernel_isig_tim  0xa55a1234    /* check password define            */
#endif

#endif
