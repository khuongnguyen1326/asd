/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer *
* Copyright (C) 2014 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/
/*******************************************************************************
* File Name    : r_spi_if.h
* Version      : 1.0
* Description  : SPI driver interface
******************************************************************************/
/*****************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 13.10.2014 1.00     First Release
******************************************************************************/
#ifndef __R_SPI_IF_H
#define __R_SPI_IF_H

/******************************************************************************
Macro definitions
******************************************************************************/
#define SPI_LCD_CHANNEL        ((uint8_t)0u)
#define SPI_PMOD2_CHANNEL      ((uint8_t)0u)
#define SPI_MICROSD_CHANNEL    ((uint8_t)0u)

#define SPI_SSL_USERCONTROL    ((uint8_t)0u)
#define SPI_SSL_APPHEADER      ((uint8_t)1u)
#define SPI_SSL_LCD            ((uint8_t)2u)
#define SPI_SSL_PMOD1          ((uint8_t)3u)
#define SPI_SSL_PMOD2          ((uint8_t)4u)
#define SPI_SSL_SDCARD         ((uint8_t)5u)

/******************************************************************************
Typedef definitions
******************************************************************************/
typedef void (*r_spi_callback_t)(void);

/******************************************************************************
Exported global variables
******************************************************************************/

/******************************************************************************
Exported global functions (to be accessed by other files)
******************************************************************************/
uint8_t R_SPI_Init(uint8_t channel);

uint8_t R_SPI_SslInit(
    uint8_t sslSelect,
    uint8_t *port,
    uint8_t *portMode,
    uint8_t pin,
    uint8_t activeHigh,
    uint8_t activePerByte
);

void R_SPI_Ssl_Assert(uint8_t sslSelect);
void R_SPI_Ssl_Clear(uint8_t sslSelect);

uint8_t R_SPI_Transfer(
    uint8_t          channel,
    uint8_t          sslSelect,
    uint8_t const    *tx_buffer,
    uint8_t* const   rx_buffer,
    uint32_t         byteCount,
    uint32_t         timeOut,
    r_spi_callback_t callback
);
uint8_t R_SPI_IsBusy(uint8_t channel);

void R_SPI_DummyCallback(void);

#endif /* __R_SPI_IF_H */

/* End of file */

