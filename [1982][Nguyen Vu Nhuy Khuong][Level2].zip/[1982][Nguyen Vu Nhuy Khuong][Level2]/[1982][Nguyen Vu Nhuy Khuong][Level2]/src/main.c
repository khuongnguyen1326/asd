/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 07.04.2017 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "def.h"      /* Define global variables and struct to use */
#include "stdio.h"    /* Standard IO library: sprintf */
#include "counting.h"     /* Mode driver interface */
#include "switch.h"   /* Switch driver interface */
#include "timer.h"
/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
//status
#define running 0
#define pausing 1
#define setting 2
#define No_Record 3
#define First_Record 4
#define Last_Record 5
//Recording
#define Max_Time  127
#define Max_Record 300 
#define Max_Display 20
#define First recordLength - 19
#define Last recordLength 
 
/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
//switch
unsigned short pre_inputvalue;
//general var
char text[20]; //scanner to output 

//diaplay timer
time_t current; //countdown ckock
unsigned int status;// pausing / running
unsigned int temp; //for record
//int total; //flag to alert changing
unsigned int count;
static int total = 1;
static int matching = 0;

//diaplay record
time_t recordT[21];
unsigned int recordLength;
unsigned int pos_Record;
unsigned int pos_Arr;
//unsigned int lastRecord;
//record countt;

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
void r_main_userinit(void);

//void displayTimer(int,int,int);
//void displayRecord(time_t [],unsigned int length, unsigned int start, unsigned int stop);

unsigned int switching();
void swapping();

void counting();
void waitSsecond(int second);
/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	int i = 0;//temporary stogare 
	static unsigned int total; 
	static unsigned int pre_status ;
	static unsigned int pre_temp = 100;
	static unsigned int pre_pos = 11111;
	//static int total = 1;
	/* Initialize user system */
	r_main_userinit();
	timer_init();
	
	/* Clear LCD display */
	 ClearLCD();
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//initmode
	//status
	 DisplayLCD(LCD_LINE1,(const uint8_t *)"PAUSING...");
	 status = pausing;
	 
	 //status = running;
	 //timer
	 current.minute = 0,current.second =0,current.centisecond = 0;
	 sprintf(text,"  %d:%d:%d  ",current.minute, current.second, current.centisecond);
	 DisplayLCD(LCD_LINE2,(uint8_t *) text);
	 //record
	 recordLength = 0, pos_Record = 0,pos_Arr = 0,i =0,total = 0;
	 timer_start();
	 while(i < 21)
	 {
		recordT[i].minute = 0; 
	 	recordT[i].second = 0;
		recordT[i].centisecond = 0;
		i++;
	 }
///////////////////////////////////////////////////////////////////////////////////////////////////////////
	/* Main loop - Infinite loop */
	while (1){
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//init     interface for user to manipulate this timer
		//checking status state
		//if(pre_status <= setting)
		//{
		//	pre_status = status;
		//}
		pre_pos = pos_Arr + recordLength;
		//if(temp<9)
		pre_temp=temp;
		pre_status = status;
		status = switching();
		
		//init mode
		if(status == setting)
		{
			//status
			 //DisplayLCD(LCD_LINE1,(const uint8_t *)"PAUSING...");
			 status = pausing;
			 //timer
			 current.minute = 0,current.second =0,current.centisecond = 0;
			 sprintf(text,"  %d:%d:%d  ",current.minute, current.second, current.centisecond);
			 DisplayLCD(LCD_LINE2,(uint8_t *) text);
			 //record
			 recordLength = 0, pos_Record = 0,pos_Arr = 0,i =0;
			 while(i < 21)
			 {
				recordT[i].minute = 0; 
			 	recordT[i].second = 0;
				recordT[i].centisecond = 0;
				i++;
			 }
		}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// line1   display current status
			/*
			checking for 2 main status of this timer and displaty it
			*/
		//if(total != current.minute + current.second + current.centisecond ||
		if(pre_status != status)
		{
			if(status == pausing)
			{
				DisplayLCD(LCD_LINE1,(const uint8_t *)"PAUSING...");
				//waitSsecond(1);
				//temp = 10;
			}
			else if(running == status)
			{
				DisplayLCD(LCD_LINE1,(const uint8_t *)"RUNNING...");
				//waitSsecond(2);
			}
			else{}
				
		}
		else{
			if(pre_temp != temp)
			{
				/*
					checking for current state and notify each of 3 special case and return to normal case 
					*/
				if ( temp == No_Record) //(recordLength == 0 &&
				{
					//temp = pre_status;
					DisplayLCD(LCD_LINE1,(const uint8_t *)"NO RECORD...");
					waitSsecond(1);
					//temp = 10;
					
				}
				else if(First_Record == temp )
				{
					//status = pausing;
					//pre_status = First_Record;
					//temp = pre_status;
					DisplayLCD(LCD_LINE1,(const uint8_t *)"FIRST RECORD...");
					waitSsecond(1);
					//temp = 
				}
				else if(Last_Record == temp)
				{
					//status = pausing; 
					//pre_status = Last_Record;
					//temp = pre_status;
					DisplayLCD(LCD_LINE1,(const uint8_t *)"LAST RECORD...");
					waitSsecond(1);
				}
				temp = 10;
				if(status == pausing)
				{
					DisplayLCD(LCD_LINE1,(const uint8_t *)"PAUSING...");
					//waitSsecond(1);
					//temp = 10;
				}
				else if(running == status)
				{
					DisplayLCD(LCD_LINE1,(const uint8_t *)"RUNNING...");
					//waitSsecond(2);
				}
				else{}
					
			}
		}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//line 2          display timer
		total = current.minute + current.second + current.centisecond;
		if(status == running)
		{
			counting(status);
			if(total != current.minute + current.second + current.centisecond ){
				sprintf(text,"  %d:%d:%d  ",current.minute, current.second, current.centisecond);
				DisplayLCD(LCD_LINE2,(uint8_t *) text); 
			}
		}
		else
		{
			//DisplayLCD(LCD_LINE1,(uint8_t *)"abrnomal..");
		}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// line 3-8         display Record
			/*
			it use 2 var to enable printout
		1st var is recordLength to enable display LCD for record
		2nd var is pos_Arr to provide the order and position to display
			*/
		if((pos_Arr + recordLength) != pre_pos){
			if(recordLength != 0)
			{
				//displat line 3 to line 8 
				
				if(recordLength < 20)
				{
					pos_Record = pos_Arr + 1;
				}
				else
				{
					pos_Record = pos_Arr + recordLength - 19;
				}
				//recorder dispalyer
				if(recordLength >= 1)
				{
					sprintf(text,"#%d:  %d:%d:%d  ",pos_Record,recordT[pos_Arr].minute, recordT[pos_Arr].second, recordT[pos_Arr].centisecond);
					DisplayLCD(LCD_LINE3,(uint8_t *) text);
				}
				//line 4
				if(recordLength>= 2)
				{
					sprintf(text,"#%d:  %d:%d:%d  ",pos_Record + 1,recordT[pos_Arr + 1].minute, recordT[pos_Arr + 1].second, recordT[pos_Arr + 1].centisecond);
					DisplayLCD(LCD_LINE4,(uint8_t *) text);
				}
				//line 5
				if(recordLength >= 3)
				{
					sprintf(text,"#%d:  %d:%d:%d  ",pos_Record + 2,recordT[pos_Arr + 2].minute, recordT[pos_Arr + 2].second, recordT[pos_Arr  + 2].centisecond);
					DisplayLCD(LCD_LINE5,(uint8_t *) text);
				}
				//line 6
				if(recordLength >= 4)
				{
					sprintf(text,"#%d:  %d:%d:%d  ",pos_Record + 3,recordT[pos_Arr + 3].minute, recordT[pos_Arr + 3].second, recordT[pos_Arr + 3].centisecond);
					DisplayLCD(LCD_LINE6,(uint8_t *) text);
				}
				//line 7
				if(recordLength >= 5)
				{
					sprintf(text,"#%d:  %d:%d:%d  ",pos_Record + 4,recordT[pos_Arr + 4].minute, recordT[pos_Arr + 4].second, recordT[pos_Arr + 4].centisecond);
					DisplayLCD(LCD_LINE7,(uint8_t *) text);
				}
				//line 8
				if(recordLength >= 6)
				{
					sprintf(text,"#%d:  %d:%d:%d  ",pos_Record + 5,recordT[pos_Arr + 5].minute, recordT[pos_Arr + 5].second, recordT[pos_Arr + 5].centisecond);
					DisplayLCD(LCD_LINE8,(uint8_t *) text);
				}
			}
		}
/////////////////////////////////////////////////////////////////////////////////////////////////////record
	}
//////////////////////////////////////////////////mainloop 
}
/////////////////////main

/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit(void)
{
	uint16_t i;

	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();	
}

//timer
/******************************************************************************
* Function Name: counting
* Description  : using the status to enable count down timer
* Arguments    : status
* Return Value : none
******************************************************************************/
void counting(unsigned int state)
{
	/*
	increase time by 10 centi second to 59:59:90 by hardware internal timer
	*/
	//boundary of this timer
	if((current.minute + current.second + current.centisecond/10) <= Max_Time )
	{
		// condition to run this timer
		//if(state == running)
		//{
			/*
		using internal timer to increase centisecond -> second -> minute -> 59:59:90
			*/
			if(count>=11)
			{
				count=0;
				current.centisecond+=10;
			}
			if(current.centisecond>=100)
			{
				current.centisecond=0;
				current.second++;
			}
			if(current.second>=60)
			{
				current.second=0;
				current.minute++;
				//the boundary in special case
				if(current.minute >= 59)
					current.minute = 59;
			}	
		//}
		//////////////////////////////////////////////////l
	}	
	//else
	//{		
		
	//}
}

/******************************************************************************
* Function Name: waitSsecond
* Description  : wait the input number of second
* Arguments    : int s
* Return Value : none
******************************************************************************/
void waitSsecond(int second)
{
	// t = second centis = centisecodn
	int centis = 0;
	int t = 0;
	/*
	a loop to wait fot the input sencond
	*/
	while(t <= second)
	{
		/*
	using internal timer to increase centisecond -> second -> 2:00
		*/
		if(count>=10){
			count=0;
			centis+=10;
		}
		if(centis==100){
			centis=0;
			t++;
		}
	}
}

//switch.c
/******************************************************************************
* Function Name: switching
* Description  : checking polling and return accoding to event occured
* Arguments    : none
* Return Value : none
******************************************************************************/

unsigned int switching()
{
	unsigned short cur_inputvalue =P7&0x70;
	
	if(cur_inputvalue != pre_inputvalue)
	{
		matching = 0;
		pre_inputvalue = cur_inputvalue;
	}
	else
	{
		matching ++;
		if(matching >= 50)
		{
			matching = 0;
			if((cur_inputvalue&0x50)==0){
				//sw4
				/*
			in the pausing state this button to reset count down timer
			in the running state this button to stop count down timer
				*/
				if(status == running){
					status = pausing;
					return pausing;
				}
				else {
					status = setting;
					return setting;
				}
			}
			if((cur_inputvalue&0x20)==0){
				//sw3
				if(status == pausing)
				{
					/*
				in the pausing state this button to start count down timer
					*/
					status = running; 
					return running;
				}
				else
				{
					/*
				in running state,  this button using for the recorder only
					*/
					//adjust the length of recorder
					recordLength++;
					////////////////////////////////////////////////////////////////////
					/*
					check condition of recorder to choose the coresponding method for record
					*/
					if(recordLength < Max_Display + 1)//21
					{
						recordT[recordLength - 1].second = current.second;
						recordT[recordLength - 1].minute = current.minute;
						recordT[recordLength - 1].centisecond = current.centisecond;
						
					}
					else if (recordLength < Max_Record + 1) //301
					{
						swapping();
						recordT[Max_Display - 1].second = current.second; //19
						recordT[Max_Display - 1].minute = current.minute;
						recordT[Max_Display - 1].centisecond = current.centisecond;
					}
					else
					{}
					///////////////////////////////////////////////////////////////////
					/*
					check condition to edit position to display
					*/
					if(recordLength < 7)
					{
						pos_Arr = 0;
					}
					else if(recordLength < Max_Display + 1)
					{
						if(pos_Arr + 5 == recordLength - 1)
						{
							pos_Arr++;	
						}
					}
					else if(recordLength < Max_Record + 1)
					{
						if(pos_Arr == 15)
						{
							//pos_Arr = recordLength - 6;	
						}	
					}
					else{}
					////////////////////////////////////////////////////////////////
					return status;
				}
			}
			if((cur_inputvalue&0x40)==0){
				//sw1
				//adjust the location of prnting starting point
				//norecord case
				if(recordLength == 0)
				{
					temp = No_Record;
					//return status;
				}
				//////////////////////////////////////////////////////////////
				//both case
				else if(recordLength < 7)
				{
					status = First_Record;
					//return First_Record;
				}
				//////////////////////////////////////////////////////////////
				else
				{
					//normal case
					/*
				adjust the location and readjust in the first location	
					*/
					pos_Arr--;
					if(pos_Arr <= 0)
					{
						//FirstR
						pos_Arr = 0;
						temp = First_Record;
						//return First_Record;
					}
					else
					{
					}
					
					//////////////////////////////////////////////////////////////
				}
				return status;
			}
			if((cur_inputvalue&0x10)==0)
			{	
				//sw2
				//adjust the location of prnting starting point
				//norecord case
				if(recordLength == 0)
				{
					temp = No_Record;
					//return No_Record;
				}
				//////////////////////////////////////////////////////////////
				//both case
				else if(recordLength < 7)
				{
					temp = Last_Record;
					//return Last_Record;
				}
				//////////////////////////////////////////////////////////////
				//normal case and need to adjust the position
				else
				{
					/*
					adjust the last location
					*/
					pos_Arr++;
					if(pos_Arr >= 15)
					{
						//FirstR
						pos_Arr = 15;
						temp = Last_Record;
						//return Last_Record;
					}
					else
					{
					}
				}
				return status;
				//////////////////////////////////////////////////////////////
			}
		}
	}
	return status;
}

/******************************************************************************
* Function Name: swapping 
* Description  : using the 1st elements as temporary stogare to stored the value of second 
and then continute using the ith element to store the i+1th element in order delete 1st elements and 
using the last elements as new stogare to store new value
* Arguments    : none
* Return Value : none
******************************************************************************/
void swapping ()
{
	int i;
	for (i = 0; i < 19; i++)
	{
		recordT[i].minute = recordT[i+1].minute;
		recordT[i].second = recordT[i+1].second;
		recordT[i].centisecond = recordT[i+1].centisecond;
	}
}
/******************************************************************************
End of file
******************************************************************************/

