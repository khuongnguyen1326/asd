/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 07.04.2017 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "def.h"      /* Define global variables and struct to use */
#include "stdio.h"    /* Standard IO library: sprintf */
#include "counting.h"     /* Mode driver interface */
#include "switch.h"   /* Switch driver interface */
/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
#define running 1
#define pausing 0
#define setting -1
#define sw1 P7_bit.no6 
#define sw2 P7_bit.no4 
#define sw3 P7_bit.no5 
/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

//general var
char text[20]; //scanner to output 
int total; //flag to alert changing

//diaplay timer
time_t current; //
unsigned int status;

//diaplay record
time_t recordT[21];
unsigned int RecordLength;
unsigned int firstRecord;
unsigned int lastRecord;
//record countt;
///////////////////////////////////////////////////////////////////////////////
uint8_t count;


/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
void r_main_userinit(void);

void displayTimer(int,int,int);
void displayRecord(time_t [],unsigned int length, unsigned int start, unsigned int stop);

unsigned int switching();
unsigned int checkPolling();

void counting();
void waitSsecond(int s);
/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	int i = 0;
	/* Initialize user system */
	r_main_userinit();
	
	/* Clear LCD display */
	ClearLCD();
	
	/* Main loop - Infinite loop */
	
	 DisplayLCD(LCD_LINE1,(const uint8_t *)"PAUSING...");
	 status = pausing;
	 //pos_scroll
	 current.minute = 0;
	 current.second =0;
	 current.centisecond = 0;
	 sprintf(text,"  %d:%d:%d  ",current.minute, current.second, current.centisecond);
	 DisplayLCD(LCD_LINE2,(uint8_t *) text);
	 //record
	 RecordLength = 0;
	 firstRecord = 0;
	 lastRecord = 0;
	//run sw3/sw1 + sw2 / sw1 /sw2
	//pause sw1 + sw2
	while (1){
		//display status 
			//pausing -> run sw3
			//pausing -> reset sw1 + sw2
			//run -> pausing sw1 + sw2
		status = switching();
		if(status == pausing)
			{
				waitSsecond(2);
				DisplayLCD(LCD_LINE1,(const uint8_t *)"PAUSING...");
			}
		else 
			{DisplayLCD(LCD_LINE1,(const uint8_t *)"RUNNING...");}
			
		if (firstRecord == 0 && lastRecord == 0)
		{
			waitSsecond(2);
			DisplayLCD(LCD_LINE1,(const uint8_t *)"NO RECORD...");
		}
		else if(firstRecord  == 0)
		{
			waitSsecond(2);
			DisplayLCD(LCD_LINE1,(const uint8_t *)"FIRST RECORD...");
		}
		else if(lastRecord == 0)
		{
			waitSsecond(2);
			DisplayLCD(LCD_LINE1,(const uint8_t *)"LAST RECORD...");
		}
		//display timer
			
				//run
			//if(total) -> display
		if(status == running)
		{
			counting(status);
			sprintf(text,"  %d:%d:%d  ",current.minute, current.second, current.centisecond);
			DisplayLCD(LCD_LINE2,(uint8_t *) text); 
		}
			
		//display record 
			//start sw1
			//stop sw2
			//no_record //sw1//sw2
		for(i = firstRecord - 1; i < lastRecord - 1;i++)
		{
			sprintf(text,"#%d:  %d:%d:%d  ",i + 1,current.minute, current.second, current.centisecond);
			DisplayLCD(LCD_LINE3,(uint8_t *) text); 
			sprintf(text,"#%d:  %d:%d:%d  ",i + 1,current.minute, current.second, current.centisecond);
			DisplayLCD(LCD_LINE4,(uint8_t *) text); 
			sprintf(text,"#%d:  %d:%d:%d  ",i + 1,current.minute, current.second, current.centisecond);
			DisplayLCD(LCD_LINE5,(uint8_t *) text); 
			sprintf(text,"#%d:  %d:%d:%d  ",i + 1,current.minute, current.second, current.centisecond);
			DisplayLCD(LCD_LINE6,(uint8_t *) text); 
			sprintf(text,"#%d:  %d:%d:%d  ",i + 1,current.minute, current.second, current.centisecond);
			DisplayLCD(LCD_LINE7,(uint8_t *) text); 
			sprintf(text,"#%d:  %d:%d:%d  ",i + 1,current.minute, current.second, current.centisecond);
			DisplayLCD(LCD_LINE8,(uint8_t *) text); 
		}
		
		  
	}
	 
}


/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit(void)
{
	uint16_t i;

	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();	
}

/******************************************************************************
* Function Name: DispalRecord 
* Description  : an interface to display sms/status to user
* Arguments    : 
* Return Value : none
******************************************************************************/
void displayRecord(time_t displayData[],unsigned int length, unsigned int start, unsigned int stop)
{
	
}

/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void displayTimer(int m,int s,int cs)
{
	sprintf(text,"  %d:%d:%d  ",m, s, cs);
	DisplayLCD(LCD_LINE2,(uint8_t *) text);
}

//timer
/******************************************************************************
* Function Name: counting
* Description  : using the status to enable count down timer
* Arguments    : status
* Return Value : none
******************************************************************************/
void counting(unsigned int state)
{
	while(current.minute == 59 && current.second == 59 && current.centisecond == 90 )
	{
		if(sw1 == 0 && sw2 == 0)
			{break;}
	}	
			
	if(state == running)
	{
		if(count==100)
		{
			count=0;
			current.centisecond+=10;
		}
		if(current.centisecond==100)
		{
			current.centisecond=0;
			current.second++;
		}
		if(current.second==60)
		{
			current.second=0;
			current.minute++;
			if(current.minute == 59)
				current.minute = 59;
		}	
	}
}

/******************************************************************************
* Function Name: waitSsecond
* Description  : wait the input number of second
* Arguments    : int s
* Return Value : none
******************************************************************************/
void waitSsecond(int s)
{
	int centis = 0;
	while(s == 2)
	{
		if(count==100){
			count=0;
			centis+=10;
		}
		if(current.centisecond==100){
			centis=0;
			s++;
		}
	}
}

//switch.c
/******************************************************************************
* Function Name: switching
* Description  : checking polling and return accoding to event occured
* Arguments    : none
* Return Value : none
******************************************************************************/
unsigned int switching()
{
	return 0;
}

/******************************************************************************
* Function Name: switching
* Description  : checking polling and return accoding to event occured
* Arguments    : none
* Return Value : none
******************************************************************************/
unsigned int checkPolling()
{
	return 1;
}

/******************************************************************************
End of file
******************************************************************************/

