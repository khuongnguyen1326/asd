#include "r_macro.h"  
#include "stdio.h"

int num_led( int);
void turn_on(int);
void init_led(void);