/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements for main function.
* Creation Date: 11-Sep-15
******************************************************************************/

/******************************************************************************
Includes 
******************************************************************************/
#pragma interrupt INTIT r_it_interrupt
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "adc.h"      /* ADC driver interface */

#include "api.h"
#include <math.h>
#include "stdio.h"
#include "string.h"
#include "led_on.h"

/******************************************************************************
Private global variables and functions
******************************************************************************/
/* Declare a variable for A/D results */
volatile float gADC_Result = 0;
volatile float final_gADC_Result = 0;
volatile int G_elapsedTime = 0;
int a = 0;
int b = 0;
volatile float temp = 0;
int k = 0; 
volatile int res;
volatile int led;
float check = 0;

/* Global buffer array for storing the ADC
result integer to string conversion  */
char * string_shown_on_lcd[10];
void LCD_Reset(void);

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	// Initialize LEDs
	init_led();
	
	// Initialize ADC module 
        ADC_Create();
	ADC_Set_OperationOn();
	
	// Enable interrupt 
	EI();
	
	//LCD_Reset();
	LCD_Reset();
	
	// Initialize SPI channel used for LCD 
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	// Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) 
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	// Initialize LCD driver 
	InitialiseLCD();
	
	// Clear LCD display 
	ClearLCD();
	
	R_IT_Create();
	G_elapsedTime = 0;
	R_IT_Start();
	
	
	// Main loop - Infinite loop 
	// Halt program in an infinite while loop 
	while (1U)
	{
	    if (G_elapsedTime >= 10)
	    {
		// Declare a temporary variable 
		
		// Start an A/D conversion 
		ADC_Start();
		

		// Wait for the A/D conversion to complete
		while(Adc_Status != ADC_DONE);

		// Clear ADC flag
		Adc_Status = 0;
		
		// Shift the ADC result contained in the 16-bit ADCR register
		gADC_Result = (float)(ADCR >> 6);
		// 330 / 1024i
		check = gADC_Result - final_gADC_Result;
		if (check <0)
		{
			check = -check;
		}
		if(check  > 1)
		{
			final_gADC_Result = gADC_Result ;
			temp = ((final_gADC_Result * 330) / 1023);
		}
		//else
		//{
		//	temp = ((gADC_Result * 330) / 1023);	
		//}
		
		
		k = (int)temp;
		led = num_led(k);
		turn_on(led);
		
		
		// Convert ADC result into a character string, and store in the local variable
		a = (k)/100U;
		b = (k)%(a*100U);
		if(b<10)
			sprintf(string_shown_on_lcd, "%d.0%d V", a, b);
		else
			sprintf(string_shown_on_lcd, "%d.%d V", a, b);
		//string_shown_on_lcd
		
		//gADC_Result
		// Display the contents of the local string lcd_buffer
		DisplayLCD(LCD_LINE1, (uint8_t*)"Volt of VR1");
		
		DisplayLCD(LCD_LINE7, (uint8_t*)string_shown_on_lcd);

		
		G_elapsedTime = 0;
	    }
	    
	}
	//R_IT_Stop();
}

void LCD_Reset(void)
{
    int i =0;
    /* Output a logic LOW level to external reset pin*/
    P13_bit.no0 = 0;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Generate a raising edge by ouput HIGH logic level to external reset pin */
    P13_bit.no0 = 1;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Output a logic LOW level to external reset pin, the reset is completed */
    P13_bit.no0 = 0;
}

__interrupt static void r_it_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    G_elapsedTime++;
    /* End user code. Do not edit comment generated here */
}

/******************************************************************************
End of file
******************************************************************************/
