#include "led_on.h"

void init_led()
{
	PM6_bit.no2 = 0;
	PM6_bit.no3 = 0;
	PM6_bit.no4 = 0;
	PM6_bit.no5 = 0;
	PM6_bit.no6 = 0;
	PM6_bit.no7 = 0;
	PM4_bit.no2 = 0;
	PM4_bit.no3 = 0;
	PM4_bit.no4 = 0;
	PM4_bit.no5 = 0;
	PM15_bit.no2 = 0;
	PM10_bit.no1 = 0;
	
	ADPC = 1;
}
void turn_on(int led)
{
	
	if(led >=1)
	{
		P6_bit.no2 = 0;
	}
	else
	{
		P6_bit.no2 = 1;
	}
	
	if(led >=2)
	{
		P4_bit.no2 = 0;
	}
	else
	{
		P4_bit.no2 = 1;
	}
	if(led >=3)
	{
		P6_bit.no3 = 0;
	}
	else
	{
		P6_bit.no3 = 1;
	}
	
	if(led >=4)
	{
		P4_bit.no3 = 0;
	}
	else
	{
		P4_bit.no3 = 1;
	}
	
	if(led >=5)
	{
		P6_bit.no4 = 0;
	}
	else
	{
		P6_bit.no4 = 1;
	}
	
	if(led >=6)
	{
		P4_bit.no4 = 0;
	}
	else
	{
		P4_bit.no4 = 1;
	}
	
	if(led >=7)
	{
		P6_bit.no5 = 0;
	}
	else
	{
		P6_bit.no5 = 1;
	}
	
	if(led >=8)
	{
		P4_bit.no5 = 0;
	}
	else
	{
		P4_bit.no5 = 1;
	}
	
	if(led >=9)
	{
		P6_bit.no6 = 0;
	}
	else
	{
		P6_bit.no6 = 1;
	}
	
	if(led >=10)
	{
		P15_bit.no2 = 0;
	}
	else
	{
		P15_bit.no2 = 1;
	}
	
	if(led >=11)
	{
		P6_bit.no7 = 0;
	}
	else
	{
		P6_bit.no7 = 1;
	}
	
	if(led >=12)
	{
		P10_bit.no1 = 0;
	}
	else
	{
		P10_bit.no1 = 1;
	}
}

int num_led( int input)
{
	if(input <= 14U)
	{
		return 0U;
	}
	else
	if(27U >= input && input >= 15U)
	{
		return 1U;
	}
	else
	if(54U >= input && input >= 28U)
	{
		return 2U;
	}
	else
	if(82U >= input && input >= 55U)
	{
		return 3U;
	}
	else
	if(110U >= input && input >= 83U)
	{
		return 4U;
	}
	else
	if(136U >= input && input >= 111U)
	{
		return 5U;
	}
	else
	if(164U >= input && input >= 137U)
	{
		return 6U;
	}
	else
	if(192U >= input && input >= 165U)
	{
		return 7U;
	}
	else
	if(220U >= input && input >= 193U)
	{
		return 8U;
	}
	else
	if(247U >= input && input >= 221U)
	{
		return 9U;
	}
	else
	if(274 >= input && input >= 248)
	{
		return 10U;
	}
	else
	if(302U >= input && input >= 275U)
	{
		return 11U;
	}
	else
	if( input >= 303U)
	{
		return 12U;
	}
	else
		return 0U;
}