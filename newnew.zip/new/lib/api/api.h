#ifndef API_H
#define API_H

#include "r_macro.h"  /* System macro and standard type definition */

void R_IT_Create(void);
void R_IT_Start(void);
void R_IT_Stop(void);


#endif

