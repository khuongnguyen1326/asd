
 /******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : led.c
* Version      : 1.00
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 07.04.2016 1.00    First Release
******************************************************************************/
#include "r_macro.h"
#include "led.h"
#include "math.h"
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "stdio.h"
#include "uart.h"
#include "stdlib.h"

unsigned char *PORT[13] ={&P6,&P4,&P6,&P4,&P6,&P4,&P6,&P4,&P6,&P15,&P6,&P10,&P4};
unsigned char LED_OFF[13]={0x04,0x04,0x08,0x08,0x10,0x10,0x20,0x20,0x40,0x04,0x80,0x02,0x02};

led_status cur_Led_Stat;

//extern numb;
/*******************************************************************************************
Function name :Led_Init
Decription    :This function setting port mode of 12 led 
******************************************************************************************/
void Led_Init()
{
	ADPC =1;
	PM4 &=0xC1;
	PM6 &=0x03;
	PM15 &=0xfb;
	PM10 &=0xfd;
	P6 =0xff;
	P4 =0xff;
	P15 =0xff;
	P10 =0xff;
	PM1_bit.no0 = 0;
}
/***********************************************************************************
Function name :check_led_status
Decription    :This function check valid of data received to turn on -off led
Paremeter     :Data received
*********************************************************************************/
void check_led_status(char buff[])
{
	//numb = 0;
	int led_number = 0;
	int i;
	char temp[3] ={'\0','\0','\0'};//converting sms to interger
	if (buff[1] == 'L')
	{
		//converting form char to int
		for (i = 3 ; buff[i] != ','; i++)
		{
			temp[i-3] = buff[i];
		}
		led_number = atoi(temp) - 3;
		//length
		if (led_number < 0 || led_number > 12)
		{
			display_msg_error();
		}
		/////////////////////////////////////////////////////////
		//contend 
		else if ((buff[i+1] != '1')&&(buff[i+1] != '0'))
		{
			display_msg_error();
		}
		/////////////////////////////////////////////////////////
		else
		{
			if(buff[i+1] =='1')
			{
				*PORT[led_number] &= ~LED_OFF[led_number];
			}
			else if (buff[i+1] =='0')
			{
				*PORT[led_number] |= LED_OFF[led_number];	
			}
		}
	}
}

/**********************************************************************************
Function name :status_led
Decription    :This function asign led status value
***************************************************************************************/
void status_led()
{
	cur_Led_Stat.BIT.bit0 = ~P6_bit.no2; /*led 3*/
	cur_Led_Stat.BIT.bit1 = ~P4_bit.no2; /*led 4*/
	cur_Led_Stat.BIT.bit2 = ~P6_bit.no3; /*led 5*/
	cur_Led_Stat.BIT.bit3 = ~P4_bit.no3; /*led 6*/
	
	cur_Led_Stat.BIT.bit4 = ~P6_bit.no4; /*led 7*/
	cur_Led_Stat.BIT.bit5 = ~P4_bit.no4; /*led 8*/
	cur_Led_Stat.BIT.bit6 = ~P6_bit.no5; /*led 9*/
	cur_Led_Stat.BIT.bit7 = ~P4_bit.no5; /*led 10*/

	cur_Led_Stat.BIT.bit8 = ~P6_bit.no6; /*led 11*/
	cur_Led_Stat.BIT.bit9 = ~P15_bit.no2; /*led 12*/
	cur_Led_Stat.BIT.bit10 = ~P6_bit.no7; /*led 13*/
	cur_Led_Stat.BIT.bit11 = ~P10_bit.no1; /*led 14*/
	
	cur_Led_Stat.BIT.bit12 = ~P4_bit.no1; /*led 15*/
	cur_Led_Stat.BIT.bit13 = 0; 
	cur_Led_Stat.BIT.bit14 = 0; 
	cur_Led_Stat.BIT.bit15 = 0; 
}
/************************************************************************************
Function name :Strasnmit_led)
Decription    :This function Convert and send led status to app
*************************************************************************************/
void Stransmit_led(void)
{
	char L_buff[13] ="$1982,L";
	uint8_t convert;
	//buffer for result
 	status_led();
	//buffer for uart
	convert = (uint8_t)((cur_Led_Stat.status_led & 0xF000) >> 12);
	L_buff[7] = (convert < 0x0A) ? (convert+0x30):(convert+0x37);
	convert = (uint8_t)((cur_Led_Stat.status_led & 0x0F00) >> 8);
	L_buff[8] = (convert < 0x0A) ? (convert+0x30):(convert+0x37);
	convert = (uint8_t)((cur_Led_Stat.status_led & 0x00F0) >> 4);
	L_buff[9] = (convert < 0x0A) ? (convert+0x30):(convert+0x37);
	convert = (uint8_t)(cur_Led_Stat.status_led & 0x000F);
	L_buff[10] = (convert < 0x0A) ? (convert+0x30):(convert+0x37);
	L_buff[11] = '^';
	//uart
	Uart_Transmit(L_buff,12);
}

/******************************************************************************
End of file
******************************************************************************/