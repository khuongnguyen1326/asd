/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements main function.
* Creation Date: 09-Sep-15
***********************************************************************************************************************/

/*******************************************************************************
* Macro Definitions
*******************************************************************************/
//#define UART_TIMEOUT        1000U
#define UART_RECEIVE_DONE   1U
#define UART_CLEAR          2U
//#define UART_RX_BUFFER_LEN  25U
#define UART_ERROR	   100U
#define MSG_ERROR	   200U

#define NO_ERROR	  10U
/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#pragma interrupt INTIT r_it_interrupt
#include "r_macro.h"
#include "r_spi_if.h"
#include "lcd.h"
#include "uart.h"
#include "adc.h"
#include "led.h"
#include "api.h"
#include <string.h>
#include "stdio.h"
#include "switch.h"
/***********************************************************************************************************************
Funtion declaration
***********************************************************************************************************************/
void r_main_userinit(void);
/**********************************************************************
extern variable declare
*************************************************************************/
//extern float final_voltage; //acd
//extern unsigned char LCD_Line; 
//extern  //sw

int error_flag = NO_ERROR;//uart
//int index=0;//uart
int lcd_status;//uart
extern int numb;
extern char temp_receive[UART_RX_BUFFER_LEN];

volatile int counter = 0; //timer
/***********************************************************************************************************************
* Function Name: main
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void)
{
	int i;
	unsigned int reset_button;
	Uart_Init();//uart int
	Uart_Start();//Start UART1 communication
	
	R_IT_Create();//timer init
	R_IT_Start(); // start timer
	
	ADC_Create();//adc init
	ADC_Start(); //Start an A/D conversion
	
	Led_Init();//led init
	
	r_main_userinit();//initialize lcd
	ClearLCD();
	
	//enable_switch = 1;//enable check switch
	while (1U)
	{   
	  	/*Get switch when error occur*/
		reset_button = polling();
/////////////////////////////////////////////////////////////
//sw3
		if (reset_button==0x50 )//&& error_flag != NO_ERROR)
		{
			reset_button = 0;
			ClearLCD();//clear lcd
		//reset led
			P1_bit.no0 =0;//light 2
			P6 = 0xff;//odd
			P4 = 0xff;//even
			P10_bit.no1 = 1;
			P15_bit.no2 = 1;
			cur_Led_Stat.status_led =0x0000;//reset buff led
		//uart
			//rest buffer
			for (i=0; i<9 ;i++)
			{
				Uart_ClearBuff(receive_data[i], UART_RX_BUFFER_LEN - 1);
			}
			//reset temp buffer for display
			Uart_ClearBuff(&temp_receive[0], UART_RX_BUFFER_LEN - 1);			
			error_flag = NO_ERROR;//err flag
			SS0 |= 0x08;
			SIR03 = 0x07;//Reset register check error of uart_error
			numb =0;//Reset index variable
		}
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//uart check err
		check_error_uart();
		if(error_flag == MSG_ERROR)
		{
			display_msg_error();
		}
		/*if no error*/		
		if(error_flag == NO_ERROR)    
		{    
		   	/* Check UART1 receive status */
		        if(status == UART_RECEIVE_DONE)
		        {
				/*If buffer emty*/
				if(lcd_status ==0)
				{
				        status = 0;	
					/* Replace the last element by NULL */
				        receive_data[numb][UART_RX_BUFFER_LEN - 1] = '\0';
					/*Display data to board*/
					display_data();
				}
				/*Reset status of buffer after display data*/
				else if (lcd_status ==1)
				{
					lcd_status =0;
				}
			}
		}
//////////////////////////////////////////////////////////////////////////////////////////		
//sampling and timer 200ms
		if (counter >= 20)//timer 200ms
		{
			Stransmit_led();//led led 3 - led 15
			Stransmit_ADC();//adc of vr1		    
			counter =0;//rest timer
		} 
	}
}
/***********************************************************************************************************************
* Function Name: r_main_userinit
* Description  : This function reset LCD setting
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void r_main_userinit(void)
{
	int i =0;
	/* Enable interrupt */
	EI();
	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}
	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;

	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);

	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
	SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
	(unsigned char *)&P14,   /* Select Port register */
	(unsigned char *)&PM14,  /* Select Port mode register */
	5,                       /* Select pin index in the port */
	0,                       /* Configure CS pin active state, 0 means active LOW level  */
	0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	InitialiseLCD();
}
__interrupt static void r_it_interrupt(void)
{
	counter++;
}
/******************************************************************************
End of file
******************************************************************************/
