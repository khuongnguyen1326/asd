/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : adc.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements device driver for ADC module.
* Creation Date: 11-Sep-15 
***********************************************************************************************************************/

/**********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
#pragma interrupt INTAD adc_interrupt
#define ready		0x01U
#define running		0x02U
#define fsr			3.3
#define Max_Val			999
#define Level_Max		1023
/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_macro.h"
#include "iodefine.h"
#include "iodefine_ext.h"
#include "adc.h"
#include "uart.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
uint16_t cur_volt = 0;
uint16_t pre_volt = 0;

volatile int Adc_Status;
int adc_result;

/***********************************************************************************************************************
* Function Name: ADC_Create
* Description  : This function initializes the AD converter.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void ADC_Create(void)
{
	ADCEN = 1U;                       /* supply AD clock */
	ADM0 = 0x00;                     /* disable AD conversion and clear ADM0 register */
	ADMK = 1U;                        /* disable INTAD interrupt */
	ADIF = 0U;                        /* clear INTAD interrupt flag */
	/* Set INTAD level2 priority */
	ADPR1 = 1U;
	ADPR0 = 0U;
	/* Set ANI0 - ANI8 pin as analog input */
	PM2 |= 0xFF;
	PM15 |= 0x01;
	ADM0 = 0x00;			/* select clock fclk/64*/
	ADM1 = 0x00;			/* select software trigger*/
	ADM2 = 0x00;			/* select 10bit resolution*/
	ADUL = 0xFF;
	ADLL = 0x00;
	ADS = 0x08;
	ADCE = 1U;                        /* enable AD comparator */
}

/***********************************************************************************************************************
* Function Name:ADC_Start
* Description  : This function starts the AD converter.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void ADC_Start(void)
{
	ADIF = 0U;  /* clear INTAD interrupt flag */
	ADMK = 0U;  /* enable INTAD interrupt */
	ADCS = 1U;  /* enable AD conversion */
	Adc_Status = running;
}

/***********************************************************************************************************************
* Function Name:ADC_Stop
* Description  : This function stops the AD converter.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void ADC_Stop(void)
{
	ADCS = 0U;  /* disable AD conversion */
	ADMK = 1U;  /* disable INTAD interrupt */
	ADIF = 0U;  /* clear INTAD interrupt flag */
}

/***********************************************************************************************************************
* Function Name: adc_interrupt
* Description  : This function is INTAD interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt static void adc_interrupt(void)
{
	Adc_Status = ready;
}

/************************************************************
* Function Name : ADC_calculate
* Description 	: This function is used to calculate  Voltage of VR1
***************************************************/
void ADC_calculate(void)
{
	float err;
	//WAIT FOT CONVERSION COMPLETE
	ADC_Start();
	while(Adc_Status != ready);
	Adc_Status = 0;
	cur_volt = ADCR >> 6;// get result form hold regiter 
///////////////////////////////////////////////////////////////////
	//check overall err
	if( cur_volt > pre_volt)
		err = (float)cur_volt - (float)pre_volt;
	else
		err = (float)pre_volt - (float)cur_volt;
	if(err > 1)
	{
		pre_volt = cur_volt;
		//err = (float)(cur_volt*fsr/Level_Max);
		adc_result = (int)((cur_volt*fsr/Level_Max*Max_Val)/fsr);
	}
//////////////////////////////////////////////////////////////////
}

/************************************************************
* Function Name : Strasnmit_ADC()
* Description 	: This function is used to send Voltage of VR1 
***************************************************/
void Stransmit_ADC()
{
	char A_Buff[13]= "$1982,A";
	ADC_calculate();
	A_Buff[7] = (char)(((int) (adc_result/100)) 	+ 48);
	A_Buff[8] = (char)(((int) ((adc_result%100)/10)) + 48);
	A_Buff[9] = (char)(((int) ((adc_result%100)%10)) + 48);
	A_Buff[10] = '^';
	Uart_Transmit(&A_Buff[0],13);
}
/******************************************************************************
End of file
******************************************************************************/
