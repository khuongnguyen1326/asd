/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements main function.
* Creation Date: 09-Sep-15
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#pragma interrupt INTIT r_it_interrupt
#include "r_macro.h"
#include "r_spi_if.h"
#include "lcd.h"
#include "uart.h"
#include "sw.h"
#include "adc.h"
#include "led.h"
#include "api.h"
#include <string.h>
#include "stdio.h"
#include "sw.h"
#include "detectsw.h"
/***********************************************************************************************************************
Funtion declaration
***********************************************************************************************************************/
void LCD_Reset(void);
/**********************************************************************888
extern variable declare
******************************************************************/

volatile int G_elapsedTime = 0; 
extern float final_voltage;
extern unsigned char LCD_Line;
extern int numb;
extern char temp_receive[UART_RX_BUFFER_LEN];
extern unsigned int check;
extern unsigned int enable_switch;
int error_flag =NO_ERROR;
int index=0;
int lcd_status;
int time_flag ;
/***********************************************************************************************************************
* Function Name: main
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void)
{
   
    
    /* Initialize UART1 communication */
    Uart_Init();
  
      /* Initialize timer */
    R_IT_Create();
  
    /* Initialize ADC module */
    ADC_Create();
    ADC_Set_OperationOn();
    /*enable check switch*/
    enable_switch =1;
  
    /* Enable interrupt */
    EI();
    
    /* Initialize SPI channel used for LCD */
    R_SPI_Init(SPI_LCD_CHANNEL);
	
    /* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
    R_SPI_SslInit(
    SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
    (unsigned char *)&P14,   /* Select Port register */
    (unsigned char *)&PM14,  /* Select Port mode register */
    5,                       /* Select pin index in the port */
    0,                       /* Configure CS pin active state, 0 means active LOW level  */
    0                        /* Configure CS pin active mode, 0 means active per transfer */
    );
    /*Reset LCD*/
    LCD_Reset();
          
    /* Start UART1 communication */
    Uart_Start();
    /* Start an A/D conversion */
    ADC_Start(); 
    /* Initialize LCD driver */
    InitialiseLCD();
    /* Clear LCD display */
    ClearLCD();

    /*LED_init*/
    ledinit();
    /* Enable timer */
    R_IT_Start();
    while (1U)
    {   
	  
	    /*Check timer after 200ms*/
	  if (time_flag ==1)
	  {
	    /*Start UART */
	    Uart_Start();
	    /*send led status*/
	    Send_led();
	    /* Start an A/D conversion */
	    ADC_Start();
	    /*Calculate Voltage of VR1*/
	    ADC_calculate();
	    /*send adc value*/
	    Send_ADC();		    
	    /*reset timer*/
	    G_elapsedTime =0;	   
	    time_flag =0;
	  } 
	  /*Get switch when error occur*/
	   check = getswitch();
	   /*Check error uart*/
	   check_error_uart();
	   if(error_flag == MSG_ERROR)
		{
		      display_msg_error();
		}
	   /*if no error*/		
	   if(error_flag == NO_ERROR)    
		{    
		   	/* Check UART1 receive status */
		        if(status == UART_RECEIVE_DONE)
		        {
				
				
					/*If buffer emty*/
					if(lcd_status ==0)
					{
				        status = 0;	
					/* Replace the last element by NULL */
					
				        receive_data[numb][UART_RX_BUFFER_LEN - 1] = '\0';
					/*Display data to board*/
					display_data();
					}
					/*Reset status of buffer after display data*/
					else if (lcd_status ==1)
					{
						//ClearLCD();
						lcd_status =0;
					}
				
			}
		}
	   /*When switch was pressed , reset LCD */
	    if (check==SW3)
	   {
		   if (error_flag != NO_ERROR)
		   {
			   int i;
			   /*clear LCD*/
			   ClearLCD();
			   /*Reset error_flag*/
			   error_flag = NO_ERROR;
			   /*Turn off light number 2*/
			   P1_bit.no0 =0;
			   /*Reset receive data buffer */
			   for (i=0; i<9 ;i++)
			   {
			   Uart_ClearBuff(receive_data[i], UART_RX_BUFFER_LEN - 1);
			   }
			   /*reset temp variable used to display data*/
			   Uart_ClearBuff(&temp_receive[0], UART_RX_BUFFER_LEN - 1);
			   /*Reset led status*/			
			   led_status_1.status_led =0x0000;
			   /*Turn off all led*/
			   P6 = 0xff;
			   P4 = 0xff;
			   P10_bit.no1 =1;
			   P15_bit.no2 =1;
			   /*Reset index variable*/
			   numb =0;
			   /*Reset register check error of uart_error*/
			   SIR03 = 0x07;
		   }
		   else
		   {
		   }
	   }	
			
			
    	}
}



/***********************************************************************************************************************
* Function Name: LCD_Reset
* Description  : This function reset LCD setting
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void LCD_Reset(void)
{
    int i =0;
    /* Output a logic LOW level to external reset pin*/
    P13_bit.no0 = 0;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Generate a raising edge by ouput HIGH logic level to external reset pin */
    P13_bit.no0 = 1;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Output a logic LOW level to external reset pin, the reset is completed */
    P13_bit.no0 = 0;
}






__interrupt static void r_it_interrupt(void)
{
    
	
	if (G_elapsedTime >=20)
	{
		time_flag=1;
		G_elapsedTime=20;
		
	}
	G_elapsedTime++;
   
}
/******************************************************************************
End of file
******************************************************************************/
