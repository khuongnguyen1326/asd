
 /******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : led.c
* Version      : 1.00
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 07.04.2016 1.00    First Release
******************************************************************************/
#include "r_macro.h"
#include "led.h"
#include "math.h"
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "stdio.h"
#include "uart.h"
#include "stdlib.h"

unsigned char *PORT[13] ={&P6,&P4,&P6,&P4,&P6,&P4,&P6,&P4,&P6,&P15,&P6,&P10,&P4};
unsigned char LED_OFF[13]={0x04,0x04,0x08,0x08,0x10,0x10,0x20,0x20,0x40,0x04,0x80,0x02,0x02};
 uint16_t value_on[13] = {0x0001,0x0002,0x0004,0x0008,
				0x0010, 0x0020,0x0040, 0x0080,
				0x0100, 0x0200,0x0400,0x0800, 0x1000}; 


char buff_led1[12] = "$1982,L0000^";
//extern numb;
/*******************************************************************************************
Function name :Led_Init
Decription    :This function setting port mode of 12 led 
******************************************************************************************/
void Led_Init()
{
	int i;
	ADPC =1;
	PM4 &=0xC1;
	PM6 &=0x03;
	PM15 &=0xfb;
	PM10 &=0xfd;
	P6 =0xff;
	P4 =0xff;
	P15 =0xff;
	P10 =0xff;
	PM1_bit.no0 = 0;
	led_value1 = 0x0000;
	for(i = 7; i <= 10;i++)
		buff_led1[i] = '0';
	Uart_Transmit( buff_led1,12);
}
/***********************************************************************************
Function name :check_led_status
Decription    :This function check valid of data received to turn on -off led
Paremeter     :Data received
*********************************************************************************/
void check_led_status(char buff[])
{
	//numb = 0;
	int led_number = 0;
	int i;
	char temp[3] ={'\0','\0','\0'};//converting sms to interger
	if (buff[1] == 'L')
	{
		//converting form char to int
		for (i = 3 ; buff[i] != ','; i++)
		{
			temp[i-3] = buff[i];
		}
		led_number = atoi(temp) - 3;
		//length
		if (led_number < 0 || led_number > 12)
		{
			display_msg_error();
		}
		/////////////////////////////////////////////////////////
		//contend 
		else if ((buff[i+1] != '1')&&(buff[i+1] != '0'))
		{
			display_msg_error();
		}
		/////////////////////////////////////////////////////////
		else
		{
			if(buff[i+1] =='1')
			{
				*PORT[led_number] &= ~LED_OFF[led_number];
				led_value1 |= value_on[led_number];
				trans_LED(led_value1);
			}
			else if (buff[i+1] =='0')
			{
				*PORT[led_number] |= LED_OFF[led_number];	
				led_value1 &= ~value_on[led_number];
				trans_LED(led_value1);
			}
		}
	}
	
}

/***********************************************************************************************************************
* Function Name: dec_to_hex
* Description  : this function return character from decimal to hexa
* Arguments    : uint16_t value
* Return Value : this fucntion return character in hexa type
***********************************************************************************************************************/
char dec_to_hex(uint16_t value){
	if((value>=0)&&(value<=9)){
		return (char) value + 48;
	}
	else{
		return (char) value + 55;
	}
}


/***********************************************************************************************************************
* Function Name: trans_LED
* Description  : change value of trans_led_buff to display LED status
* Arguments    : uint16_t value
* Return Value : None
***********************************************************************************************************************/
void trans_LED(uint16_t value){
	uint16_t temp;
	//Get bit 15-12
	temp = value >> 12;
	temp = temp & 0x0F;
	buff_led1[7] = dec_to_hex(temp);
	//get bit 11-8
	temp = value >> 8;
	temp = temp & 0x0F;
	buff_led1[8] = dec_to_hex(temp);
	//get bit 7-4
	temp = value >> 4;
	temp = temp & 0x0F;
	buff_led1[9]= dec_to_hex(temp);
	// bit 3-0
	temp = value;
	temp = temp & 0x0F;
	buff_led1[10] = dec_to_hex(temp);
}


/************************************************************************************
Function name :Strasnmit_led)
Decription    :This function Convert and send led status to app
*************************************************************************************/
void Stransmit_led(void)
{
	Uart_Transmit( buff_led1,12);
}

/************************************************************************************
Function name :reset led
Decription    :
*************************************************************************************/
void reset_led(void)
{
	
}


/******************************************************************************
End of file
******************************************************************************/